# 🚀 DVM Miner - Plug & Play Edition

**Decentralized Vector Memory Network Miner**

The easiest way to start mining on the DVM Network. Earn REM tokens by providing RAM and computational power to the decentralized AI infrastructure.

---

## ⚡ Quick Start (5 Minutes)

### Windows

```powershell
# 1. Download and extract the miner package
# 2. Open PowerShell in the package directory
# 3. Run the interactive setup:
.\interactive_setup.ps1

# That's it! The script will guide you through everything.
```

### Linux / macOS

```bash
# 1. Download and extract the miner package
# 2. Open terminal in the package directory
# 3. Make the script executable and run it:
chmod +x interactive_setup.sh
./interactive_setup.sh

# That's it! The script will guide you through everything.
```

---

## 📦 What's Included

- ✅ **Pre-configured settings**: Coordinator URL and miner secret already set
- ✅ **Interactive setup wizard**: Guides you through wallet creation and configuration
- ✅ **Automatic wallet creation**: Optional Sui wallet generation
- ✅ **Default referral**: Start earning with our default referral
- ✅ **Cross-platform**: Works on Windows, Linux, and macOS

---

## 🎯 What You Need

1. **Python 3.11+** - [Download here](https://www.python.org/downloads/)
2. **4GB+ RAM** (more = higher rewards)
3. **Sui Wallet** (can be created during setup)
4. **Stable internet connection**

---

## 💰 Reward Tiers

Choose your commitment level:

| Tier | RAM   | Multiplier | Monthly Potential* |
|------|-------|------------|--------------------|
| T1   | 4GB   | 0.8×       | ~40 REM            |
| T2   | 8GB   | 1.0×       | ~100 REM           |
| T3   | 16GB  | 1.3×       | ~260 REM           |
| T4   | 32GB  | 1.6×       | ~640 REM           |
| T5   | 64GB  | 2.0×       | ~1,600 REM         |
| T6   | 128GB | 2.5×       | ~4,000 REM         |

*Estimated based on 100% uptime and good performance*

---

## 🔧 Manual Setup (Advanced)

If you prefer manual configuration:

### 1. Install Dependencies

```bash
cd miner
pip install -r requirements.txt
pip install -e .
```

### 2. Create Sui Wallet

```bash
# Install Sui CLI first (if not installed)
# Linux/macOS:
cargo install --locked --git https://github.com/MystenLabs/sui.git --branch mainnet sui

# Windows:
choco install sui

# Create wallet
sui client new-address ed25519

# Get your address
sui client active-address
```

### 3. Initialize Miner

```bash
dvm-miner init --sui-address YOUR_SUI_ADDRESS
```

### 4. Configure

Edit `~/.dvm_miner/config.json`:

```json
{
  "coordinator_url": "wss://api.getrem.online/miners_ws",
  "max_ram_gb": 8,
  "miner_secret": "xuLHbzL7awVGHe-PQpAmwRuVJodUtwFRKGhSnAKS8pQ",
  "sui_address": "0xYOUR_ADDRESS_HERE",
  "referral_address": "f5e3a292-b3fc-480e-93c6-b475cffd6c18"
}
```

### 5. Start Mining

```bash
dvm-miner start
```

---

## 📊 Referral System

### Earn 10% Extra Rewards!

When someone uses **your** Node ID as their referral code, you earn 10% bonus from their mining rewards!

**After registration, find your Referral ID in:**
- Terminal output (displayed on first registration)
- File: `~/.dvm_miner/referral_info.txt`

**Share it with friends to multiply your earnings!**

### Using a Referral Code

When you set up your miner, you can enter a referral code (Node ID) from an existing miner. They will earn 10% bonus from your rewards, and it doesn't reduce your earnings!

Default referral: `f5e3a292-b3fc-480e-93c6-b475cffd6c18`

---

## 🎮 Running the Miner

### Foreground (See All Logs)

```bash
dvm-miner start
```

Press `Ctrl+C` to stop gracefully.

### Background (Linux/Mac)

```bash
nohup dvm-miner start > miner.log 2>&1 &
```

### As a Service (Linux - Recommended)

Create `/etc/systemd/system/dvm-miner.service`:

```ini
[Unit]
Description=DVM Miner Service
After=network.target

[Service]
Type=simple
User=YOUR_USERNAME
WorkingDirectory=/home/YOUR_USERNAME
ExecStart=/usr/bin/python3 -m dvm_miner.cli start
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable dvm-miner
sudo systemctl start dvm-miner
sudo systemctl status dvm-miner
```

---

## 🔍 Monitoring

### Check Status

```bash
dvm-miner status
```

### View Logs

```bash
tail -f ~/.dvm_miner/miner.log
```

### Check Referral Info

```bash
cat ~/.dvm_miner/referral_info.txt
```

---

## ⚙️ Configuration Reference

| Parameter        | Description                        | Default                                      |
|------------------|-------------------------------------|----------------------------------------------|
| coordinator_url  | WebSocket endpoint                 | wss://api.getrem.online/miners_ws            |
| max_ram_gb       | RAM commitment (4/8/16/32/64/128)  | 4                                            |
| miner_secret     | Shared secret for authentication   | (pre-filled)                                 |
| sui_address      | Your Sui wallet address            | (required - set during setup)                |
| referral_address | Referral code (Node ID)            | f5e3a292-b3fc-480e-93c6-b475cffd6c18         |
| embedding_dim    | Vector dimensions                  | 384                                          |
| index_version    | HNSW index version                 | 1                                            |

---

## 🐛 Troubleshooting

### Connection Issues

```bash
# Test coordinator connectivity
ping api.getrem.online
```

### Signature Verification Failed

Make sure your Sui CLI is configured and the active address matches the one in your config:

```bash
sui client active-address
```

### Low Tier Assigned

Increase `max_ram_gb` in your config to get a higher tier and better rewards.

### Miner Keeps Disconnecting

1. Check network stability
2. Ensure server has enough RAM
3. Check logs for specific errors: `tail -f ~/.dvm_miner/miner.log`

---

## 💡 Pro Tips

1. **Run 24/7**: Consistent uptime = maximum rewards (uptime rewards are quadratic!)
2. **Higher Tier**: More RAM = better multiplier
3. **Pass Challenges**: Allocate real RAM, don't fake it
4. **Refer Others**: Share your referral ID to earn passive income
5. **Monitor Regularly**: Check logs and status daily

---

## 🔒 Security

- ✅ **Keep your Sui recovery phrase safe** - Write it down physically
- ✅ **Protect config.json** - Contains sensitive information
- ✅ **Use dedicated wallet** - Don't use your main Sui wallet
- ✅ **Regular backups** - Backup your wallet keys

```bash
# Set proper permissions (Linux/Mac)
chmod 600 ~/.dvm_miner/config.json
```

---

## 📈 Maximize Your Earnings

Your rewards are calculated as:

```
Total Reward = Mining Reward + Referral Bonuses

Mining Reward = Base × Tier_Multiplier × Uptime² × Exit_Multiplier

Base = (Capacity×50%) + (Challenges×40%) + (Queries×10%)
```

**To maximize earnings:**
1. ✅ Commit maximum RAM you can
2. ✅ Stay online 24/7 (uptime is squared!)
3. ✅ Refer friends for passive income
4. ✅ Always shutdown gracefully (no penalties)

---

## 🆘 Support

- **Documentation**: See `QUICKSTART.md` for detailed guide
- **Logs**: Check `~/.dvm_miner/miner.log` for debugging
- **Coordinator**: Contact network administrator if issues persist

---

## 📜 Version Info

- **Package**: Plug & Play Edition
- **Version**: Phase 4
- **Last Updated**: 2025-12-02
- **Network**: Mainnet
- **Coordinator**: wss://api.getrem.online/miners_ws

---

## 🎉 Ready to Mine?

```bash
# Linux/macOS
./interactive_setup.sh

# Windows
.\interactive_setup.ps1
```

**Happy Mining! 🚀**
