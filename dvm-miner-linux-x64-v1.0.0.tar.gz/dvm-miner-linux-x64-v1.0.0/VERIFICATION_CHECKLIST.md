# ✅ DVM Miner - Post-Setup Verification Checklist

Use this checklist to verify your miner is set up correctly and earning rewards.

---

## 📋 Pre-Start Checklist

Before starting your miner, verify:

- [ ] **Python 3.11+ is installed**
  ```bash
  python3 --version  # or: python --version on Windows
  ```
  Should show: Python 3.11.x or higher

- [ ] **Config file exists**
  ```bash
  # Linux/macOS:
  ls ~/.dvm_miner/config.json
  
  # Windows:
  dir %USERPROFILE%\.dvm_miner\config.json
  ```

- [ ] **Config has required fields**
  Open config.json and verify:
  - [ ] `sui_address` is filled (starts with `0x`, 66 characters)
  - [ ] `max_ram_gb` is set (4, 8, 16, 32, 64, or 128)
  - [ ] `coordinator_url` is `wss://api.getrem.online/miners_ws`
  - [ ] `miner_secret` is filled
  - [ ] `referral_address` is set (default or custom)

- [ ] **Sui wallet is accessible** (if using Sui CLI)
  ```bash
  sui client active-address
  ```
  Should return your wallet address

---

## 🚀 Startup Checklist

When you start the miner:

- [ ] **Start command runs without errors**
  ```bash
  dvm-miner start
  ```

- [ ] **See "Connecting to coordinator" message**
  
- [ ] **See "Registration successful" message**
  
- [ ] **See referral information displayed**
  ```
  ============================================================
  ✅ MINER REGISTERED SUCCESSFULLY!
  ============================================================
  Node ID: [your-node-id]
  ------------------------------------------------------------
  💰 EARN EXTRA REWARDS WITH REFERRALS!
  Your Referral ID: [your-node-id]
  ```

- [ ] **No error messages in terminal**
  Common errors to watch for:
  - ❌ "Signature verification failed" → Check Sui wallet
  - ❌ "Invalid miner secret" → Contact admin
  - ❌ "Connection refused" → Check internet/coordinator

- [ ] **Miner stays running** (doesn't crash or exit)

---

## 📁 Files Checklist

After successful startup, these files should exist:

- [ ] **Config file**
  ```
  ~/.dvm_miner/config.json  (or %USERPROFILE%\.dvm_miner\config.json on Windows)
  ```

- [ ] **Referral info file**
  ```
  ~/.dvm_miner/referral_info.txt
  ```
  Open it and verify your Node ID is there

- [ ] **Log file** (may take a few minutes to appear)
  ```
  ~/.dvm_miner/logs/miner.log
  ```

- [ ] **Vector index directories** (created as data is stored)
  ```
  ~/.dvm_miner/indices/
  ```

---

## 💰 Earning Checklist

To verify you're earning rewards:

- [ ] **Miner is online in coordinator**
  Ask admin or check monitoring dashboard

- [ ] **Receiving challenges**
  Look for in logs:
  ```
  "Received PoRAM challenge"
  "PoRAM challenge completed"
  ```

- [ ] **Uptime is accumulating**
  Miner should stay connected 24/7

- [ ] **No abandonment penalties**
  Gracefully stop with Ctrl+C or systemctl stop (not kill -9)

---

## 🔗 Referral System Checklist

- [ ] **You have a referral ID**
  Check `~/.dvm_miner/referral_info.txt`

- [ ] **You used a referral code during setup**
  (Either default or custom)

- [ ] **You can share your referral ID with others**
  Format: `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`

- [ ] **When someone uses your code, you'll earn 10% bonus**
  (No action needed, automatic)

---

## 🛠️ Troubleshooting Steps

If something is wrong:

### Problem: Miner won't start

```bash
# Check Python
python3 --version

# Check if miner package is installed
python3 -c "import dvm_miner; print('OK')"

# Reinstall if needed
cd miner_package_latest/miner
pip install -e . --force-reinstall
```

### Problem: Connection issues

```bash
# Test internet
ping google.com

# Test coordinator endpoint
ping api.getrem.online

# Check config
cat ~/.dvm_miner/config.json | grep coordinator_url
```

### Problem: Signature verification failed

```bash
# Check Sui CLI
sui client active-address

# Verify it matches config
cat ~/.dvm_miner/config.json | grep sui_address

# If different, update config
nano ~/.dvm_miner/config.json  # or notepad on Windows
```

### Problem: Low rewards

- [ ] Is miner running 24/7?
- [ ] Is RAM actually allocated? (Check system RAM usage)
- [ ] Are you passing challenges? (Check logs)
- [ ] Is your tier correct? (Higher RAM = higher tier)

---

## 📊 Performance Monitoring

### Daily Checks

- [ ] **Miner is still running**
  ```bash
  ps aux | grep dvm-miner  # Linux/macOS
  Get-Process | Select-String dvm  # Windows
  ```

- [ ] **No errors in logs**
  ```bash
  tail -n 50 ~/.dvm_miner/logs/miner.log
  ```

- [ ] **Challenges are being completed**
  Look for:
  ```
  "PoRAM challenge completed"
  "response_time_ms": [should be < 1000ms for good performance]
  ```

### Weekly Checks

- [ ] **Uptime percentage** (should be close to 100%)
  
- [ ] **Reward accumulation** (check coordinator dashboard or admin)

- [ ] **No disk space issues**
  ```bash
  df -h ~/.dvm_miner  # Linux/macOS
  dir ~/.dvm_miner    # Windows
  ```

---

## 🎯 Success Criteria

Your miner is successful if:

✅ Runs 24/7 without crashes  
✅ Passes all PoRAM challenges  
✅ Response time < 1 second for challenges  
✅ No connection drops (or auto-reconnects)  
✅ Uptime > 95%  
✅ Earnings visible in coordinator  
✅ Referrals are tracked (if you shared your ID)

---

## 📞 Getting Help

If you checked everything and still have issues:

1. **Check logs first**
   ```bash
   tail -f ~/.dvm_miner/logs/miner.log
   ```

2. **Review documentation**
   - START_HERE.md
   - README.md
   - QUICKSTART.md

3. **Contact support**
   - Provide your Node ID
   - Describe the issue
   - Share relevant log entries

---

## 🚀 Next Steps

Once everything is verified:

1. **Set up auto-start** (systemd service on Linux)
2. **Monitor regularly** (daily for first week, then weekly)
3. **Share your referral ID** (earn passive income!)
4. **Consider upgrading tier** (more RAM = more rewards)
5. **Join the community** (stay updated on network changes)

---

**Checklist Complete?** → Start mining and earning! 💰

**Issues?** → Review troubleshooting steps above 🔧

**All good?** → Share your referral ID! 🎉
