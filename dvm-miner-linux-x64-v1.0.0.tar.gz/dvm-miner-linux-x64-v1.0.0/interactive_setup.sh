#!/bin/bash
# Interactive Setup Script for DVM Miner (Linux/Mac)
# This script guides users through the complete miner setup with minimum friction

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Check if already configured (Fix #3: Skip setup if already done)
DATA_DIR="${HOME}/.dvm_miner"
CONFIG_FILE="$DATA_DIR/config.json"

if [ -f "$CONFIG_FILE" ]; then
    echo ""
    echo -e "${GREEN}╔════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║          ✓ Miner Already Configured!              ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}Your miner is already set up!${NC}"
    echo -e "Config: ${YELLOW}$CONFIG_FILE${NC}"
    echo ""
    echo -e "${BLUE}To start mining:${NC}"
    echo -e "  ${GREEN}dvm-miner start${NC}"
    echo ""
    echo -e "  Or use the quick-start script:"
    echo -e "  ${GREEN}./start_miner.sh${NC}"
    echo ""
    echo -e "${YELLOW}To reconfigure (will erase current setup):${NC}"
    echo -e "  ${RED}rm -rf $DATA_DIR${NC}"
    echo ""
    exit 0
fi

# ASCII Art Banner
echo ""
echo -e "${CYAN}╔════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║                                                    ║${NC}"
echo -e "${CYAN}║          ${GREEN}DVM MINER INTERACTIVE SETUP${CYAN}              ║${NC}"
echo -e "${CYAN}║                                                    ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}Welcome to the DVM Network Mining Setup!${NC}"
echo -e "This wizard will guide you through the setup process step by step."
echo ""

# Step 1: Check Python
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Step 1/5: Checking Python Installation${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

# Find Python - prioritize python3.11, then python3
PYTHON_CMD=""
if command -v python3.11 &> /dev/null; then
    PYTHON_CMD="python3.11"
elif command -v python3.12 &> /dev/null; then
    PYTHON_CMD="python3.12"
elif command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
else
    echo -e "${RED}✗ Python is not installed!${NC}"
    echo "Please install Python 3.11 or higher"
    exit 1
fi

# Check Python version
python_version=$($PYTHON_CMD --version 2>&1 | awk '{print $2}')
python_major=$($PYTHON_CMD -c 'import sys; print(sys.version_info.major)')
python_minor=$($PYTHON_CMD -c 'import sys; print(sys.version_info.minor)')

echo -e "${YELLOW}Found: Python $python_version${NC}"

# Check if version is >= 3.8 (lowered requirement for broader compatibility)
if [ "$python_major" -lt 3 ] || ([ "$python_major" -eq 3 ] && [ "$python_minor" -lt 8 ]); then
    echo -e "${RED}✗ Python $python_version is too old (need 3.8+)${NC}"
    echo "Please upgrade Python to 3.8 or higher"
    exit 1
fi

echo -e "${GREEN}✓ Python $python_version found (compatible)${NC}"
echo ""

# Step 2: Check/Install Sui CLI
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Step 2/5: Sui CLI Setup${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

SUI_ADDRESS=""

if command -v sui &> /dev/null; then
    echo -e "${GREEN}✓ Sui CLI is already installed${NC}"
    
    # Check if wallet exists
    if sui client active-address &> /dev/null; then
        DETECTED_ADDRESS=$(sui client active-address 2>/dev/null)
        echo -e "${GREEN}✓ Found existing Sui wallet${NC}"
        echo -e "  Address: ${CYAN}$DETECTED_ADDRESS${NC}"
        echo ""
        read -p "Do you want to use this wallet for mining? (y/n): " use_existing
        
        if [[ $use_existing =~ ^[Yy]$ ]]; then
            SUI_ADDRESS=$DETECTED_ADDRESS
            echo -e "${GREEN}✓ Using existing wallet${NC}"
        fi
    fi
else
    echo -e "${YELLOW}⚠ Sui CLI is not installed${NC}"
    echo -e "${YELLOW}Installing Sui CLI automatically (downloading binary)...${NC}"
    echo ""
    
    # Detect OS and architecture
    OS=$(uname -s | tr '[:upper:]' '[:lower:]')
    ARCH=$(uname -m)
    
    # Map architecture
    if [[ "$ARCH" == "x86_64" ]]; then
        ARCH="x86_64"
    elif [[ "$ARCH" == "aarch64" ]] || [[ "$ARCH" == "arm64" ]]; then
        ARCH="arm64"
    else
        echo -e "${RED}✗ Unsupported architecture: $ARCH${NC}"
        echo "Supported: x86_64, arm64"
        exit 1
    fi
    
    # Determine download URL based on OS
    SUI_VERSION="v1.37.4"  # Latest stable version
    
    if [[ "$OS" == "linux" ]]; then
        if [[ "$ARCH" == "x86_64" ]]; then
            DOWNLOAD_URL="https://github.com/MystenLabs/sui/releases/download/mainnet-$SUI_VERSION/sui-mainnet-$SUI_VERSION-ubuntu-x86_64.tgz"
        else
            echo -e "${RED}✗ No pre-built binary for Linux ARM64${NC}"
            echo "Please install from source or use x86_64 system"
            exit 1
        fi
    elif [[ "$OS" == "darwin" ]]; then
        if [[ "$ARCH" == "x86_64" ]]; then
            DOWNLOAD_URL="https://github.com/MystenLabs/sui/releases/download/mainnet-$SUI_VERSION/sui-mainnet-$SUI_VERSION-macos-x86_64.tgz"
        elif [[ "$ARCH" == "arm64" ]]; then
            DOWNLOAD_URL="https://github.com/MystenLabs/sui/releases/download/mainnet-$SUI_VERSION/sui-mainnet-$SUI_VERSION-macos-arm64.tgz"
        fi
    else
        echo -e "${RED}✗ Unsupported OS: $OS${NC}"
        exit 1
    fi
    
    # Create installation directory
    SUI_INSTALL_DIR="$HOME/.sui/bin"
    mkdir -p "$SUI_INSTALL_DIR"
    
    echo -e "${YELLOW}Downloading Sui CLI binary...${NC}"
    echo "  URL: $DOWNLOAD_URL"
    
    # Download and extract
    TMP_DIR=$(mktemp -d)
    cd "$TMP_DIR"
    
    if command -v curl &> /dev/null; then
        curl -L -o sui.tgz "$DOWNLOAD_URL"
    elif command -v wget &> /dev/null; then
        wget -O sui.tgz "$DOWNLOAD_URL"
    else
        echo -e "${RED}✗ Neither curl nor wget found${NC}"
        echo "Please install curl or wget"
        exit 1
    fi
    
    # Extract the binary
    tar -xzf sui.tgz
    
    # Move binary to install directory
    chmod +x sui
    mv sui "$SUI_INSTALL_DIR/"
    
    # Clean up
    cd - > /dev/null
    rm -rf "$TMP_DIR"
    
    # Add to PATH
    export PATH="$SUI_INSTALL_DIR:$PATH"
    
    # Add to shell profile for persistence
    if [[ -f "$HOME/.bashrc" ]]; then
        if ! grep -q ".sui/bin" "$HOME/.bashrc"; then
            echo 'export PATH="$HOME/.sui/bin:$PATH"' >> "$HOME/.bashrc"
        fi
    fi
    if [[ -f "$HOME/.zshrc" ]]; then
        if ! grep -q ".sui/bin" "$HOME/.zshrc"; then
            echo 'export PATH="$HOME/.sui/bin:$PATH"' >> "$HOME/.zshrc"
        fi
    fi
    
    # Verify installation
    if command -v sui &> /dev/null; then
        echo ""
        echo -e "${GREEN}✓ Sui CLI installed successfully${NC}"
        sui --version
    else
        echo -e "${RED}✗ Failed to install Sui CLI${NC}"
        echo "Please install manually from: https://docs.sui.io/guides/developer/getting-started/sui-install"
        exit 1
    fi
fi

# Create new wallet if needed
if [ -z "$SUI_ADDRESS" ] && command -v sui &> /dev/null; then
    echo ""
    read -p "Do you want to create a new Sui wallet now? (y/n): " create_wallet
    
    if [[ $create_wallet =~ ^[Yy]$ ]]; then
        echo ""
        echo -e "${YELLOW}Creating new Sui wallet (mainnet)...${NC}"
        echo ""
        
        # Create new wallet with auto-answered prompts and capture output
        # Answers: y (connect to full node), mainnet URL (empty = default mainnet), 0 (ed25519)
        WALLET_OUTPUT=$(printf "y\n\n0\n" | sui client new-address ed25519 2>&1)
        
        # Display the output
        echo "$WALLET_OUTPUT"
        
        # Parse the address from the output - it's after "│ address" 
        # Format: │ address        │ 0x7bf43074cbc94c2263403158e304a2194004e1f1a5295b58d3102772beacd22a          │
        NEW_ADDRESS=$(echo "$WALLET_OUTPUT" | grep "│ address" | grep -oE '0x[a-fA-F0-9]{64}')
        
        if [ -n "$NEW_ADDRESS" ]; then
            # CRITICAL FIX #1: Set this address as the active address
            echo ""
            echo -e "${YELLOW}→ Setting new address as active...${NC}"
            sui client switch --address "$NEW_ADDRESS"
            
            # Verify the switch worked
            ACTIVE_CHECK=$(sui client active-address 2>/dev/null)
            if [ "$ACTIVE_CHECK" = "$NEW_ADDRESS" ]; then
                SUI_ADDRESS="$NEW_ADDRESS"
                echo -e "${GREEN}✓ Address activated successfully${NC}"
            else
                echo -e "${RED}✗ Warning: Failed to set address as active${NC}"
                echo "  Expected: $NEW_ADDRESS"
                echo "  Got: $ACTIVE_CHECK"
                SUI_ADDRESS="$NEW_ADDRESS"
            fi
        else
            # Fallback: try getting the most recently created address
            echo -e "${YELLOW}→ Using fallback address detection...${NC}"
            SUI_ADDRESS=$(sui client addresses | tail -n 1 | awk '{print $NF}')
            if [ -n "$SUI_ADDRESS" ] && [[ "$SUI_ADDRESS" =~ ^0x[a-fA-F0-9]{64}$ ]]; then
                sui client switch --address "$SUI_ADDRESS"
            fi
        fi
        
        echo ""
        echo -e "${GREEN}✓ Wallet created successfully!${NC}"
        echo -e "${CYAN}  Address: $SUI_ADDRESS${NC}"
        echo ""
        echo -e "${RED}╔════════════════════════════════════════════════════╗${NC}"
        echo -e "${RED}║           IMPORTANT: BACKUP YOUR WALLET!          ║${NC}"
        echo -e "${RED}╚════════════════════════════════════════════════════╝${NC}"
        echo ""
        echo "Your wallet recovery phrase was shown above (12 words)."
        echo -e "${YELLOW}Write it down and store it in a safe place!${NC}"
        echo "You will need it to recover your wallet if you lose access."
        echo ""
        read -p "Press Enter after you have safely stored your recovery phrase..."
    fi
fi

# Manual address input if still not set
if [ -z "$SUI_ADDRESS" ]; then
    echo ""
    while true; do
        read -p "Enter your Sui wallet address (0x...): " manual_address
        
        # Validate format
        if [[ $manual_address =~ ^0x[a-fA-F0-9]{64}$ ]]; then
            SUI_ADDRESS=$manual_address
            echo -e "${GREEN}✓ Valid address format${NC}"
            break
        else
            echo -e "${RED}✗ Invalid address format. Must be 0x followed by 64 hex characters${NC}"
        fi
    done
fi

echo ""

# Step 3: Install Dependencies
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Step 3/5: Installing Miner Dependencies${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

# First, ensure pip is installed for the correct Python version
if ! $PYTHON_CMD -m pip --version &> /dev/null; then
    echo -e "${YELLOW}pip is not installed for Python $python_version, installing it now...${NC}"
    
    # For Python 3.11, we need python3.11-distutils
    if [[ "$PYTHON_CMD" == "python3.11" ]]; then
        if command -v apt-get &> /dev/null; then
            apt-get install -y python3.11-distutils python3.11-pip > /dev/null 2>&1 || true
        fi
    fi
    
    # Try apt-get first (Debian/Ubuntu)
    if command -v apt-get &> /dev/null; then
        apt-get update > /dev/null 2>&1
        apt-get install -y python3-pip > /dev/null 2>&1
    # Try yum (CentOS/RHEL)
    elif command -v yum &> /dev/null; then
        yum install -y python3-pip > /dev/null 2>&1
    # Fallback: download and install pip directly
    else
        echo -e "${YELLOW}Installing pip via get-pip.py...${NC}"
        curl -sS https://bootstrap.pypa.io/get-pip.py | $PYTHON_CMD
    fi
    
    # Verify pip is now available
    if $PYTHON_CMD -m pip --version &> /dev/null; then
        echo -e "${GREEN}✓ pip installed successfully${NC}"
    else
        echo -e "${RED}✗ Failed to install pip${NC}"
        echo "Please install pip manually: apt-get install python3-pip"
        exit 1
    fi
fi

cd miner
echo -e "${YELLOW}Installing Python packages with $PYTHON_CMD...${NC}"
# Use $PYTHON_CMD -m pip to ensure we use the right Python version
$PYTHON_CMD -m pip install -q --upgrade pip
$PYTHON_CMD -m pip install -q -r requirements.txt
$PYTHON_CMD -m pip install -q -e .
cd ..

echo -e "${GREEN}✓ Dependencies installed${NC}"
echo ""

# Step 4: Configure RAM
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Step 4/5: RAM Configuration${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

echo ""
echo "Choose how much RAM you want to commit to the network:"
echo ""
echo "  Tier    RAM        Multiplier  Monthly Potential*"
echo "  ────────────────────────────────────────────────"
echo "  T1      4GB        0.8×        ~40 REM"
echo "  T2      8GB        1.0×        ~100 REM"
echo "  T3      16GB       1.3×        ~260 REM"
echo "  T4      32GB       1.6×        ~640 REM"
echo "  T5      64GB       2.0×        ~1,600 REM"
echo "  T6      128GB      2.5×        ~4,000 REM"
echo ""
echo "  * Estimated based on 100% uptime and good performance"
echo ""

while true; do
    read -p "Enter RAM commitment in GB (4, 8, 16, 32, 64, or 128): " ram_gb
    
    if [[ $ram_gb =~ ^(4|8|16|32|64|128)$ ]]; then
        echo -e "${GREEN}✓ RAM commitment set to ${ram_gb}GB${NC}"
        break
    else
        echo -e "${RED}✗ Please choose: 4, 8, 16, 32, 64, or 128${NC}"
    fi
done

echo ""

# Step 5: Referral Code
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Step 5/5: Referral Code (Optional)${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

echo ""
echo "If someone referred you to DVM Network, enter their referral code."
echo "They will earn 10% bonus from your mining rewards (doesn't affect your rewards)."
echo ""
DEFAULT_REFERRAL="f5e3a292-b3fc-480e-93c6-b475cffd6c18"
read -p "Enter referral code (press Enter to use default): " referral_code

if [ -z "$referral_code" ]; then
    referral_code=$DEFAULT_REFERRAL
    echo -e "${YELLOW}Using default referral code${NC}"
fi

echo ""

# Initialize Miner
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Initializing Miner...${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

DATA_DIR="${HOME}/.dvm_miner"
mkdir -p "$DATA_DIR"

# Create config
cat > "$DATA_DIR/config.json" <<EOF
{
  "coordinator_url": "wss://api.getrem.online/miners_ws",
  "data_dir": "$DATA_DIR",
  "node_id": "",
  "max_ram_gb": $ram_gb,
  "embedding_dim": 384,
  "index_version": 1,
  "miner_secret": "xuLHbzL7awVGHe-PQpAmwRuVJodUtwFRKGhSnAKS8pQ",
  "sui_address": "$SUI_ADDRESS",
  "referral_address": "$referral_code"
}
EOF

echo -e "${GREEN}✓ Configuration saved to $DATA_DIR/config.json${NC}"
echo ""

# Success!
echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║              SETUP COMPLETED! 🎉                   ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}Configuration Summary:${NC}"
echo -e "  Sui Address:     ${YELLOW}$SUI_ADDRESS${NC}"
echo -e "  RAM Commitment:  ${YELLOW}${ram_gb}GB${NC}"
echo -e "  Referral Code:   ${YELLOW}$referral_code${NC}"
echo -e "  Data Directory:  ${YELLOW}$DATA_DIR${NC}"
echo ""

# Auto-start the miner
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Starting Miner Automatically...${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# CRITICAL: Ensure the Sui active address matches our config before starting
CURRENT_ACTIVE=$(sui client active-address 2>/dev/null)
if [ "$CURRENT_ACTIVE" != "$SUI_ADDRESS" ]; then
    echo -e "${YELLOW}⚠ Active Sui address doesn't match config, fixing...${NC}"
    echo "  Config address: $SUI_ADDRESS"
    echo "  Active address: $CURRENT_ACTIVE"
    sui client switch --address "$SUI_ADDRESS"
    
    # Verify the switch worked
    CURRENT_ACTIVE=$(sui client active-address 2>/dev/null)
    if [ "$CURRENT_ACTIVE" = "$SUI_ADDRESS" ]; then
        echo -e "${GREEN}✓ Active address updated successfully${NC}"
    else
        echo -e "${RED}✗ Failed to set active address${NC}"
        echo "Please manually run: sui client switch --address $SUI_ADDRESS"
        exit 1
    fi
else
    echo -e "${GREEN}✓ Sui active address matches config${NC}"
fi

echo ""
echo -e "${YELLOW}The miner will now start and register with the coordinator.${NC}"
echo -e "${YELLOW}Please wait for the registration confirmation...${NC}"
echo ""

# Start the miner (it's already in PATH from the miner installation)
dvm-miner start

# FIX #2: Display referral info after miner stops
echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}💰 YOUR REFERRAL INFORMATION${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

if [ -f "$DATA_DIR/referral_info.txt" ]; then
    cat "$DATA_DIR/referral_info.txt"
else
    echo -e "${YELLOW}Referral info will be saved after successful registration${NC}"
    echo "File: $DATA_DIR/referral_info.txt"
fi

echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${YELLOW}Important:${NC}"
echo "  • Keep your Sui wallet recovery phrase safe"
echo "  • The miner needs to run 24/7 for best rewards"
echo "  • Monitor your miner regularly"
echo ""
echo -e "${GREEN}To restart the miner:${NC} ${CYAN}dvm-miner start${NC}"
echo ""
