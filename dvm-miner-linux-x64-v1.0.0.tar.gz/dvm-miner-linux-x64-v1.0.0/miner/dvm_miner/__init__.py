"""DVM Miner package."""

# Add shared protocol to path
import sys
from pathlib import Path

shared_path = Path(__file__).parent.parent.parent / "shared"
if str(shared_path) not in sys.path:
    sys.path.insert(0, str(shared_path))

__version__ = "1.0.0"
