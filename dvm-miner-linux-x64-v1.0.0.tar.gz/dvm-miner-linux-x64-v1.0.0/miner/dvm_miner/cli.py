"""Miner CLI commands."""

import json
import os
import sys
import shutil
import subprocess
from pathlib import Path

import click

# Add parent directories to path for imports
script_dir = Path(__file__).parent
miner_dir = script_dir.parent  # miner directory (or package root)

# Add miner dir to path (allows importing dvm_miner if not already in path)
if str(miner_dir) not in sys.path:
    sys.path.insert(0, str(miner_dir))

# Try to find shared module
# 1. In package root (sibling of dvm_miner)
package_shared = miner_dir / "shared"
# 2. In repo root (sibling of miner directory)
repo_shared = miner_dir.parent / "shared"

if package_shared.exists():
    # If shared is in package root, it's already importable because miner_dir is in path
    pass
elif repo_shared.exists():
    # If shared is in repo root, add repo root to path
    repo_root = miner_dir.parent
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))

from dvm_miner.config import MinerConfig, load_config, save_config
from dvm_miner.engine import VectorEngine
from dvm_miner.node import MinerNode


@click.group()
def cli():
    """DVM Miner CLI."""
    pass


@cli.command()
@click.option(
    "--data-dir",
    type=click.Path(),
    default=str(Path.home() / ".dvm_miner"),
    help="Data directory for miner"
)
@click.option(
    "--sui-address",
    type=str,
    prompt="Your Sui address for rewards",
    help="Sui address (0x followed by 64 hex characters)"
)
def init(data_dir: str, sui_address: str):
    """Initialize miner configuration."""
    # Validate Sui address format
    if not sui_address.startswith("0x") or len(sui_address) != 66:
        click.echo("Error: Invalid Sui address format. Expected 0x followed by 64 hex characters", err=True)
        return
    
    try:
        int(sui_address, 16)  # Validate hex
    except ValueError:
        click.echo("Error: Invalid Sui address - not valid hexadecimal", err=True)
        return
    
    data_path = Path(data_dir)
    data_path.mkdir(parents=True, exist_ok=True)
    
    config_path = data_path / "config.json"
    
    if config_path.exists():
        click.echo(f"Config already exists at {config_path}")
        config = load_config(config_path)
        config.sui_address = sui_address  # Update Sui address
    else:
        config = MinerConfig.default()
        config.data_dir = str(data_path)
        config.sui_address = sui_address
        save_config(config, config_path)
        click.echo(f"Created new config at {config_path}")
    
    save_config(config, config_path)  # Save updated config
    click.echo(f"Node ID: {config.node_id}")
    click.echo(f"Sui Address: {config.sui_address}")
    click.echo(f"Data directory: {config.data_dir}")
    click.echo(f"Coordinator URL: {config.coordinator_url}")


def setup_sui_wallet():
    """Setup Sui wallet if needed and return address."""
    if not shutil.which("sui"):
        return None
        
    # Check if already set up
    try:
        res = subprocess.run(["sui", "client", "active-address"], capture_output=True, text=True)
        if res.returncode == 0:
            return res.stdout.strip()
    except Exception:
        return None
        
    click.echo("⚙️  Initializing Sui Wallet (Mainnet)...")
    try:
        # Initialize config: y (connect), (enter for default url), 0 (ed25519)
        # We pipe inputs to handle the interactive prompts
        input_str = "y\nhttps://fullnode.mainnet.sui.io:443\n0\n"
        subprocess.run(["sui", "client"], input=input_str, text=True, capture_output=True, timeout=15)
        
        # Now check address
        res = subprocess.run(["sui", "client", "active-address"], capture_output=True, text=True)
        if res.returncode == 0:
            addr = res.stdout.strip()
            click.echo(f"✅ Wallet created! Address: {addr}")
            click.echo(f"⚠️  IMPORTANT: Run 'sui keytool export --key-identity {addr}' to backup your private key!")
            return addr
            
    except Exception as e:
        click.echo(f"⚠️  Automatic wallet setup failed: {e}")
        
    return None


@cli.command()
@click.option(
    "--data-dir",
    type=click.Path(),
    default=None,
    help="Data directory for miner"
)
def start(data_dir: str):
    """Start the miner node."""
    # Support environment variable override
    if data_dir is None:
        data_dir = os.getenv("DATA_DIR", str(Path.home() / ".dvm_miner"))
    
    data_path = Path(data_dir)
    config_path = data_path / "config.json"
    
    # Initialize if config doesn't exist
    # Initialize if config doesn't exist
    if not config_path.exists():
        click.echo("Welcome to DVM Miner! First time setup...")
        
        # 1. Ask for Sui Wallet Address
        default_sui = None
        
        # Try to auto-detect or create wallet
        detected_address = setup_sui_wallet()
        if detected_address:
            click.echo(f"Found active Sui address: {detected_address}")
            if click.confirm("Do you want to use this address?", default=True):
                default_sui = detected_address
        
        while True:
            prompt_msg = "Please enter your Sui Wallet Address (0x...)"
            if default_sui:
                sui_address = click.prompt(prompt_msg, type=str, default=default_sui)
            else:
                sui_address = click.prompt(prompt_msg, type=str)
                
            if sui_address.startswith("0x") and len(sui_address) == 66:
                try:
                    int(sui_address, 16)
                    break
                except ValueError:
                    pass
            click.echo("Invalid Sui address. It must start with 0x and be 66 characters long (hex).")

        # 2. Ask for RAM commitment
        max_ram_gb = click.prompt("How much RAM (in GB) do you want to commit to the network?", type=int, default=4)
        
        # 3. Ask for Referral Address
        default_referral = "f5e3a292-b3fc-480e-93c6-b475cffd6c18"
        referral_address = click.prompt(
            "Enter referral address (optional, press Enter to use default)", 
            type=str, 
            default=default_referral, 
            show_default=False
        )
        
        # Create and save config
        config = MinerConfig.default()
        config.data_dir = str(data_path)
        config.sui_address = sui_address
        config.max_ram_gb = max_ram_gb
        config.referral_address = referral_address
        
        save_config(config, config_path)
        click.echo(f"Configuration saved to {config_path}")
        
        # Display Referral Info
        click.echo("\n" + "="*50)
        click.echo("🎉 CONGRATULATIONS! You are now a DVM Miner.")
        click.echo("="*50)
        click.echo(f"Your Miner Node ID: {config.node_id}")
        click.echo("-" * 50)
        click.echo("💰 EARN MORE REWARDS!")
        click.echo(f"Your Referral ID is: {config.node_id}")
        click.echo("Share this ID with others. You will earn 10% of their mining rewards!")
        click.echo("="*50 + "\n")
        
        # Save referral info to file
        try:
            with open(data_path / "referral_info.txt", "w") as f:
                f.write("DVM Miner Referral Information\n")
                f.write("==============================\n\n")
                f.write(f"Your Node ID: {config.node_id}\n")
                f.write(f"Your Referral ID: {config.node_id}\n\n")
                f.write("Share your Referral ID with others to earn 10% of their rewards!\n")
            click.echo(f"Referral info saved to {data_path / 'referral_info.txt'}")
        except Exception as e:
            click.echo(f"Could not save referral info file: {e}")
            
        click.echo("Starting miner...")
    
    # Load config
    config = load_config(config_path)
    config.data_dir = str(data_path)  # Ensure data_dir is set correctly
    
    # Check if sui_address is set
    if not config.sui_address:
        click.echo("Error: Sui address not configured. Please run 'dvm-miner init --sui-address <your-address>'", err=True)
        return
    
    # Override with environment variables if present
    coordinator_url_env = os.getenv("COORDINATOR_URL")
    if coordinator_url_env:
        config.coordinator_url = coordinator_url_env
    
    click.echo(f"Starting miner node {config.node_id}...")
    click.echo(f"Connecting to {config.coordinator_url}")
    
    node = MinerNode(config)
    
    try:
        node.start()
    except Exception as e:
        click.echo(f"Error: {e}")
        node.shutdown()


@cli.command()
@click.option(
    "--data-dir",
    type=click.Path(),
    default=str(Path.home() / ".dvm_miner"),
    help="Data directory for miner"
)
def status(data_dir: str):
    """Show miner status."""
    data_path = Path(data_dir)
    config_path = data_path / "config.json"
    
    if not config_path.exists():
        click.echo(f"Config not found at {config_path}")
        return
    
    config = load_config(config_path)
    
    click.echo(f"Node ID: {config.node_id}")
    click.echo(f"Data directory: {config.data_dir}")
    click.echo(f"Coordinator URL: {config.coordinator_url}")
    click.echo(f"Max RAM: {config.max_ram_gb} GB")
    
    # Load engine to get stats
    try:
        engine = VectorEngine(
            data_dir=data_path,
            embedding_dim=config.embedding_dim,
            max_ram_gb=config.max_ram_gb
        )
        
        total_vectors = engine.get_total_vectors()
        bytes_used = engine.get_bytes_used()
        collections = len(engine.indices)
        
        click.echo(f"\nCollections: {collections}")
        click.echo(f"Total vectors: {total_vectors}")
        click.echo(f"Bytes used: {bytes_used / (1024**2):.2f} MB")
        click.echo(f"Capacity: {(bytes_used / engine.max_bytes) * 100:.1f}%")
    except Exception as e:
        click.echo(f"Error loading engine: {e}")


if __name__ == "__main__":
    cli()
