"""Miner configuration."""

import json
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional


@dataclass
class MinerConfig:
    """Miner configuration."""
    coordinator_url: str
    data_dir: str
    node_id: str
    max_ram_gb: int
    embedding_dim: int
    index_version: int
    miner_secret: str
    sui_address: str = ""  # Sui address for rewards (required in Phase 3)
    referral_address: str = ""  # Optional: Referral address
    sui_keypair_path: str = ""  # Optional: Path to Sui keypair file for signing
    
    @classmethod
    def default(cls) -> "MinerConfig":
        """Create default configuration."""
        return cls(
            coordinator_url="wss://api.getrem.online/miners_ws",
            data_dir=str(Path.home() / ".dvm_miner"),
            node_id=str(uuid.uuid4()),
            max_ram_gb=4,
            embedding_dim=384,
            index_version=1,
            miner_secret="xuLHbzL7awVGHe-PQpAmwRuVJodUtwFRKGhSnAKS8pQ"
        )


def load_config(path: Path) -> MinerConfig:
    """
    Load configuration from JSON file.
    
    Args:
        path: Path to config.json file
        
    Returns:
        MinerConfig instance
    """
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    
    with open(path, "r") as f:
        data = json.load(f)
    
    # Generate node_id if missing
    if "node_id" not in data or not data["node_id"]:
        data["node_id"] = str(uuid.uuid4())
    
    return MinerConfig(**data)


def save_config(config: MinerConfig, path: Path):
    """
    Save configuration to JSON file.
    
    Args:
        config: MinerConfig instance
        path: Path to save config.json
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(path, "w") as f:
        json.dump(asdict(config), f, indent=2)
