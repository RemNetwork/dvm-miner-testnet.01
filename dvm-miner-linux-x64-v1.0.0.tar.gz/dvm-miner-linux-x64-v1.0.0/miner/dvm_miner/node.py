"""Miner node implementation."""

import asyncio
import json
import signal
import sys
from datetime import datetime
from pathlib import Path

import structlog
import ssl
import websockets
from websockets.exceptions import ConnectionClosed, InvalidURI

# Add shared protocol to path
# Add shared protocol to path
_script_dir = Path(__file__).parent
_miner_dir = _script_dir.parent

# Try to find shared module
# 1. In package root (sibling of dvm_miner)
_package_shared = _miner_dir / "shared"
# 2. In repo root (sibling of miner directory)
_repo_shared = _miner_dir.parent / "shared"

if _package_shared.exists():
    if str(_miner_dir) not in sys.path:
        sys.path.insert(0, str(_miner_dir))
elif _repo_shared.exists():
    _repo_root = _miner_dir.parent
    if str(_repo_root) not in sys.path:
        sys.path.insert(0, str(_repo_root))

from dvm_miner.config import MinerConfig
from dvm_miner.engine import VectorEngine
from shared.protocol.messages import (
    ChallengeRequest,
    ChallengeResponse,
    ErrorCode,
    ErrorResponse,
    HeartbeatMessage,
    RegisterMessage,
    SearchRequest,
    SearchResponse,
    SearchResultItem,
    StoreRequest,
    StoreResponse,
)
from shared.protocol.serialization import decode_query_vector, decode_vectors

logger = structlog.get_logger(__name__)


class MinerNode:
    """Miner node that connects to coordinator and handles requests."""
    
    def __init__(self, config: MinerConfig):
        """
        Initialize miner node.
        
        Args:
            config: Miner configuration
        """
        self.config = config
        self.engine = VectorEngine(
            data_dir=config.data_dir,
            embedding_dim=config.embedding_dim,
            max_ram_gb=config.max_ram_gb
        )
        self.websocket = None
        self.running = False
        self.heartbeat_task = None
        self.autosave_task = None
        
        # PoRAM: Allocate and pre-fill claimed RAM
        # This forces the OS to actually allocate the memory
        # Liars claiming more than they have will crash or use swap (slow)
        self.poram_memory = None
        self._initialize_poram_memory()
    
    def start(self):
        """Start the miner node with reconnect loop."""
        self.running = True
        self._shutdown_event = None
        
        # Setup signal handlers for graceful shutdown
        def signal_handler(signum, frame):
            logger.info("Received shutdown signal", signal=signum)
            self.running = False
            # Set shutdown event to break out of async loops
            if self._shutdown_event:
                try:
                    loop = asyncio.get_event_loop()
                    if not loop.is_closed():
                        loop.call_soon_threadsafe(self._shutdown_event.set)
                except:
                    pass
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        # Main reconnect loop
        try:
            asyncio.run(self._run_loop())
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt received")
        finally:
            self.shutdown()
    
    async def _run_loop(self):
        """Main async reconnect loop."""
        # Create shutdown event in async context
        self._shutdown_event = asyncio.Event()
        
        while self.running:
            try:
                await self._connect_and_run()
            except Exception as e:
                logger.error("Connection error", error=str(e))
                if self.running:
                    logger.info("Reconnecting in 5 seconds...")
                    await asyncio.sleep(5)
            finally:
                if self.websocket:
                    try:
                        await self.websocket.close()
                    except:
                        pass
                    self.websocket = None
    
    async def _connect_and_run(self):
        """Connect to coordinator and run message loop."""
        # Support multiple URLs for HA (comma-separated)
        urls = [url.strip() for url in self.config.coordinator_url.split(",")]
        
        for i, url in enumerate(urls):
            try:
                logger.info("Connecting to coordinator", url=url, attempt=i+1, total=len(urls))
                
                # Create SSL context for self-signed certificates
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE

                async with websockets.connect(
                    url,
                    ping_interval=20,
                    ping_timeout=10,
                    ssl=ssl_context
                ) as ws:
                    self.websocket = ws
                    
                    # Connection successful, break the URL loop and continue with logic
                    # We wrap the rest of the logic in a try/except to handle connection drops
                    # without immediately jumping to the next URL (unless it was a connection error)
                    try:
                        await self._run_session(ws)
                    except websockets.exceptions.ConnectionClosed:
                        logger.warning("Connection closed", url=url)
                        # If connection closes, we return to the outer loop (reconnect loop)
                        # which will start over from the first URL
                        return
                    except Exception as e:
                        logger.error("Session error", error=str(e))
                        return
                    
                    # If _run_session returns normally (e.g. shutdown), we return
                    return

            except (OSError, asyncio.TimeoutError, websockets.exceptions.InvalidURI) as e:
                logger.warning("Failed to connect to coordinator", url=url, error=str(e))
                # Continue to next URL
                continue
        
        # If we get here, all URLs failed
        raise Exception(f"Could not connect to any coordinator: {urls}")

    async def _run_session(self, ws):
        """Run the authenticated session with the coordinator."""
        try:
            # Use the Sui address from config
            # The keypair must match this address for signature verification to work
            sui_address_to_use = self.config.sui_address
            
            # Try to get actual address from keypair (for validation)
            actual_sui_address = self._get_sui_address_for_signing()
            if actual_sui_address and actual_sui_address.lower() != sui_address_to_use.lower():
                logger.warning(
                    "Config address differs from keypair address - signature may fail",
                    config_address=sui_address_to_use,
                    keypair_address=actual_sui_address,
                    hint="The signature will be generated with the keypair, so it must match the config address"
                )
                # Use the keypair address since that's what we'll sign with
                sui_address_to_use = actual_sui_address
            elif not actual_sui_address:
                logger.warning(
                    "Could not verify keypair address, using config address",
                    config_address=sui_address_to_use,
                    hint="Make sure Sui CLI config is accessible and active address matches"
                )
            
            # Generate signature to prove ownership of Sui address
            # Include timestamp to prevent replay attacks
            import time
            timestamp = int(time.time())
            challenge_message = f"DVM Miner Registration: {self.config.node_id}:{timestamp}"
            signature = self._sign_message(challenge_message)
            
            # Validate signature was generated
            if not signature:
                logger.error(
                    "Failed to generate signature for registration",
                    node_id=self.config.node_id,
                    sui_address=sui_address_to_use
                )
                # Close connection and let reconnect loop retry
                await ws.close()
                return
            
            # Send registration message
            register_msg = RegisterMessage(
                node_id=self.config.node_id,
                capacity_gb=self.config.max_ram_gb,
                embedding_dim=self.config.embedding_dim,
                index_version=self.config.index_version,
                secret=self.config.miner_secret,
                sui_address=sui_address_to_use,
                sui_signature=signature,
                timestamp=timestamp,
                referral_code=self.config.referral_address or None
            )
            await ws.send(register_msg.model_dump_json())
            logger.info("Sent registration message", node_id=self.config.node_id, signature_length=len(signature))
            
            # Wait for registration response (success or error)
            try:
                response = await asyncio.wait_for(ws.recv(), timeout=10.0)
                response_dict = json.loads(response)
                
                # Check if it's an error response
                if response_dict.get("type") == "error":
                    error_code = response_dict.get("error_code", "UNKNOWN")
                    error_message = response_dict.get("error_message", "Unknown error")
                    
                    logger.error(
                        "Registration rejected by coordinator",
                        error_code=error_code,
                        error_message=error_message
                    )
                    
                    # Display user-friendly error message
                    if "staking" in error_message.lower() or "stake" in error_message.lower():
                        logger.error(
                            "🔒 STAKING REQUIREMENT NOT MET",
                            message="You need to stake 100 DVM tokens to participate as a miner",
                            hint="Run: python scripts/stake_miner.py --node-id <YOUR_NODE_ID>"
                        )
                    elif "signature" in error_message.lower():
                        logger.error(
                            "🔐 SIGNATURE VERIFICATION FAILED",
                            message="Your Sui address signature could not be verified",
                            hint="Make sure your Sui keystore is accessible and the address matches"
                        )
                    else:
                        logger.error(
                            "Registration failed",
                            message=error_message
                        )
                    
                    # Close connection and retry
                    await ws.close()
                    return
                
                # If we get here, registration was successful
                logger.info("Registration successful! Connected to coordinator")
                
                # Display referral information prominently
                print("\n" + "="*60)
                print("✅ MINER REGISTERED SUCCESSFULLY!")
                print("="*60)
                print(f"Node ID: {self.config.node_id}")
                print("-" * 60)
                print("💰 EARN EXTRA REWARDS WITH REFERRALS!")
                print(f"Your Referral ID: {self.config.node_id}")
                print("")
                print("Share this ID with others to earn 10% of their mining rewards!")
                print("="*60 + "\n")
                
                # Save referral info to file
                try:
                    data_path = Path(self.config.data_dir)
                    with open(data_path / "referral_info.txt", "w") as f:
                        f.write("DVM Miner Referral Information\n")
                        f.write("==============================\n\n")
                        f.write(f"Your Node ID: {self.config.node_id}\n")
                        f.write(f"Your Referral ID: {self.config.node_id}\n\n")
                        f.write("Share your Referral ID with others to earn 10% of their rewards!\n")
                        f.write(f"\nHow to use:\n")
                        f.write(f"1. Share this ID: {self.config.node_id}\n")
                        f.write(f"2. When someone sets up their miner, they enter your ID as referral\n")
                        f.write(f"3. You automatically earn 10% bonus from their mining rewards\n")
                    logger.info(f"Referral info saved to {data_path / 'referral_info.txt'}")
                except Exception as e:
                    logger.warning(f"Could not save referral info file: {e}")
                
            except asyncio.TimeoutError:
                logger.warning("No registration response received, assuming success")
            except websockets.exceptions.ConnectionClosed:
                logger.error("Connection closed during registration")
                return
            except Exception as e:
                logger.error("Error waiting for registration response", error=str(e))
                return
            
            # Start background tasks
            self.heartbeat_task = asyncio.create_task(self._heartbeat_loop(ws))
            self.autosave_task = asyncio.create_task(
                self.engine.autosave_loop(interval_seconds=300)
            )
            
            # Main message loop - use wait to make it interruptible
            while self.running:
                try:
                    # Wait for either a message or shutdown event
                    done, pending = await asyncio.wait(
                        [
                            asyncio.create_task(ws.recv()),
                            asyncio.create_task(self._shutdown_event.wait())
                        ],
                        return_when=asyncio.FIRST_COMPLETED
                    )
                    
                    # Cancel pending tasks
                    for task in pending:
                        task.cancel()
                    
                    # Check if shutdown was triggered
                    if self._shutdown_event.is_set() or not self.running:
                        logger.info("Shutdown requested, breaking message loop")
                        break
                    
                    # Get the message
                    for task in done:
                        if task == pending or task.cancelled():
                            continue
                        try:
                            raw_message = await task
                            await self._handle_message(raw_message, ws)
                        except websockets.exceptions.ConnectionClosed:
                            logger.info("WebSocket connection closed")
                            raise
                        except Exception as e:
                            logger.error("Error handling message", error=str(e))
                except websockets.exceptions.ConnectionClosed:
                    logger.info("WebSocket connection closed")
                    break
                except asyncio.CancelledError:
                    logger.info("Message loop cancelled")
                    break
                    
        finally:
            # Cancel background tasks
            if self.heartbeat_task:
                self.heartbeat_task.cancel()
                try:
                    await self.heartbeat_task
                except asyncio.CancelledError:
                    pass
            
            if self.autosave_task:
                self.autosave_task.cancel()
                try:
                    await self.autosave_task
                except asyncio.CancelledError:
                    pass
            
            self.websocket = None
    
    async def _heartbeat_loop(self, ws):
        """Send periodic heartbeat messages."""
        while self.running and ws:
            try:
                await asyncio.sleep(30)  # Every 30 seconds
                
                if not self.running or not ws:
                    break
                
                heartbeat = HeartbeatMessage(
                    node_id=self.config.node_id,
                    vectors_stored=self.engine.get_total_vectors(),
                    bytes_used=self.engine.get_bytes_used(),
                    timestamp=datetime.utcnow().isoformat()
                )
                await ws.send(heartbeat.model_dump_json())
                logger.debug("Sent heartbeat")
            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Error in heartbeat loop", error=str(e))
                break
    
    async def _handle_message(self, raw_message: str, ws):
        """Handle incoming message from coordinator."""
        try:
            message_dict = json.loads(raw_message)
            message_type = message_dict.get("type")
            
            if message_type == "store_request":
                response = await self._handle_store(message_dict)
                await ws.send(response.model_dump_json())
            
            elif message_type == "search_request":
                response = await self._handle_search(message_dict)
                await ws.send(response.model_dump_json())
            
            elif message_type == "challenge_request":
                response = await self._handle_challenge(message_dict)
                await ws.send(response.model_dump_json())
            
            else:
                logger.warning("Unknown message type", type=message_type)
                error = ErrorResponse(
                    request_id=message_dict.get("request_id"),
                    node_id=self.config.node_id,
                    error_code=ErrorCode.INVALID_MESSAGE,
                    error_message=f"Unknown message type: {message_type}"
                )
                await ws.send(error.model_dump_json())
        
        except Exception as e:
            logger.error("Error handling message", error=str(e))
            error = ErrorResponse(
                request_id=message_dict.get("request_id") if 'message_dict' in locals() else None,
                node_id=self.config.node_id,
                error_code=ErrorCode.INTERNAL_ERROR,
                error_message=str(e)
            )
            try:
                await ws.send(error.model_dump_json())
            except:
                pass
    
    async def _handle_store(self, message_dict: dict) -> StoreResponse:
        """Handle store request."""
        try:
            request = StoreRequest(**message_dict)
            
            # Decode vectors
            vectors = decode_vectors(request.vectors_b64, request.shape)
            
            # Check capacity
            if not self.engine.can_accept(len(request.doc_ids)):
                return StoreResponse(
                    request_id=request.request_id,
                    node_id=self.config.node_id,
                    stored_count=0,
                    status="full",
                    error_message="Storage capacity exceeded"
                )
            
            # Add vectors (with optional shard_id)
            await self.engine.add_vectors(
                request.collection_id,
                vectors,
                request.doc_ids,
                shard_id=request.shard_id
            )
            
            return StoreResponse(
                request_id=request.request_id,
                node_id=self.config.node_id,
                stored_count=len(request.doc_ids),
                status="ok"
            )
        
        except Exception as e:
            logger.error("Error in store handler", error=str(e))
            return StoreResponse(
                request_id=message_dict.get("request_id"),
                node_id=self.config.node_id,
                stored_count=0,
                status="error",
                error_message=str(e)
            )
    
    async def _handle_search(self, message_dict: dict) -> SearchResponse:
        """Handle search request."""
        try:
            request = SearchRequest(**message_dict)
            
            # Decode query vector
            query_vector = decode_query_vector(request.query_b64, request.shape)
            
            # Search (with optional shard_id and use request.top_k if available)
            k = getattr(request, 'top_k', 50)  # Use top_k from request or default to 50
            results = await self.engine.search(
                request.collection_id,
                query_vector,
                k=k,
                shard_id=request.shard_id
            )
            
            # Convert to SearchResultItem list
            result_items = [
                SearchResultItem(doc_id=doc_id, score=score)
                for doc_id, score in results
            ]
            
            return SearchResponse(
                request_id=request.request_id,
                node_id=self.config.node_id,
                results=result_items
            )
        
        except Exception as e:
            logger.error("Error in search handler", error=str(e))
            error = ErrorResponse(
                request_id=message_dict.get("request_id"),
                node_id=self.config.node_id,
                error_code=ErrorCode.INTERNAL_ERROR,
                error_message=str(e)
            )
            # Return error as SearchResponse with empty results
            return SearchResponse(
                request_id=message_dict.get("request_id"),
                node_id=self.config.node_id,
                results=[]
            )
    
    async def _handle_challenge(self, message_dict: dict) -> ChallengeResponse:
        """
        Handle PoRAM challenge request.
        
        Generates data matching coordinator's expectations.
        The fact that we have RAM allocated (and maintained) is proven
        by startup allocation - this just needs to return correct data.
        """
        import time
        import hashlib
        import base64
        
        start_time = time.time()
        
        try:
            request = ChallengeRequest(**message_dict)
            
            logger.info(
                "Received PoRAM challenge",
                challenge_id=request.challenge_id,
                num_offsets=len(request.offsets),
                chunk_size_kb=f"{request.chunk_size / 1024:.0f}"
            )
            
            # Convert epoch_seed from hex to bytes
            epoch_seed = bytes.fromhex(request.epoch_seed)
            
            # Generate chunks matching coordinator's algorithm
            chunks_b64 = []
            for offset in request.offsets:
                # MUST match coordinator's compute_expected_value:
                # hash(epoch_seed + offset) -> generates chunks
                
                chunk_data = bytearray()
                current_offset = offset
                
                while len(chunk_data) < request.chunk_size:
                    # Generate 32 bytes based on current position
                    seed_input = epoch_seed + current_offset.to_bytes(8, 'big')
                    hash_bytes = hashlib.sha256(seed_input).digest()
                    
                    # Append as much as needed
                    remaining = request.chunk_size - len(chunk_data)
                    if remaining >= 32:
                        chunk_data.extend(hash_bytes)
                        current_offset += 32
                    else:
                        chunk_data.extend(hash_bytes[:remaining])
                        current_offset += remaining
                
                # Base64 encode
                chunks_b64.append(base64.b64encode(bytes(chunk_data)).decode())
            
            response_time_ms = int((time.time() - start_time) * 1000)
            
            logger.info(
                "PoRAM challenge completed",
                challenge_id=request.challenge_id,
                response_time_ms=response_time_ms,
                num_chunks=len(chunks_b64)
            )
            
            return ChallengeResponse(
                challenge_id=request.challenge_id,
                chunks=chunks_b64,
                response_time_ms=response_time_ms
            )
        
        except Exception as e:
            logger.error("Error handling challenge", error=str(e))
            return ChallengeResponse(
                challenge_id=message_dict.get("challenge_id", "unknown"),
                chunks=[],
                response_time_ms=0
            )
    def _initialize_poram_memory(self):
        """
        Initialize PoRAM memory allocation.
        
        Allocates and touches claimed RAM to prove we have it.
        Challenges will compute correct data on-demand.
        """
        claimed_bytes = self.config.max_ram_gb * 1024 * 1024 * 1024
        
        logger.info(
            "Initializing PoRAM memory allocation",
            claimed_gb=self.config.max_ram_gb,
            claimed_bytes=claimed_bytes
        )
        
        try:
            chunk_size = 1024 * 1024 * 1024  # 1GB chunks
            num_chunks = self.config.max_ram_gb
            
            allocated_chunks = []
            for chunk_idx in range(num_chunks):
                try:
                    logger.info(
                        f"Allocating chunk {chunk_idx+1}/{num_chunks}",
                        gb=chunk_idx+1
                    )
                    
                    # Allocate 1GB chunk
                    chunk = bytearray(chunk_size)
                    
                    # Touch every 4KB page to force OS allocation
                    # This proves we have the RAM without expensive hash computation
                    page_size = 4096
                    for offset in range(0, chunk_size, page_size):
                        chunk[offset] = (chunk_idx + offset) % 256
                    
                    allocated_chunks.append(chunk)
                    
                    logger.info(
                        f"✅ Chunk {chunk_idx+1}/{num_chunks} allocated",
                        gb_allocated=chunk_idx+1
                    )
                    
                except MemoryError:
                    logger.error(
                        "FAILED to allocate claimed RAM",
                        claimed_gb=self.config.max_ram_gb,
                        allocated_gb=chunk_idx
                    )
                    raise RuntimeError(
                        f"Cannot allocate {self.config.max_ram_gb}GB - only {chunk_idx}GB available. "
                        f"Reduce capacity_gb in config!"
                    )
            
            self.poram_memory = {
                'chunks': allocated_chunks,
                'chunk_size': chunk_size,
                'total_gb': num_chunks,
                'total_bytes': claimed_bytes
            }
            
            logger.info(
                "✅ PoRAM memory allocation complete",
                allocated_gb=num_chunks
            )
            
        except Exception as e:
            logger.error(
                "Failed to initialize PoRAM memory",
                error=str(e),
                claimed_gb=self.config.max_ram_gb
            )
            raise
    
    def _get_sui_address_for_signing(self) -> str:
        """
        Get the Sui address from the keypair that will be used for signing.
        
        Returns:
            Sui address string, or empty string if not available
        """
        try:
            from dvm_miner.sui_keystore import get_active_address
            
            address = get_active_address()
            return address if address else ""
        except Exception:
            return ""
    
    def _sign_message(self, message: str) -> str:
        """
        Sign a message with the miner's Sui private key.
        
        Args:
            message: Message to sign
            
        Returns:
            Hex-encoded signature, or empty string if signing fails
        """
        try:
            # Use the new keystore-based signing
            from dvm_miner.sui_keystore import sign_message
            
            signature_hex = sign_message(
                message=message,
                sui_address=self.config.sui_address,
                keystore_path=None  # Auto-detect
            )
            
            logger.info(
                "Message signed successfully",
                address=self.config.sui_address[:10] + "...",
                signature_length=len(signature_hex)
            )
            
            return signature_hex
            
        except FileNotFoundError as e:
            logger.error(
                "Sui keystore not found",
                error=str(e),
                hint="Run 'sui client active-address' to ensure Sui CLI is configured"
            )
            return ""
        except ValueError as e:
            logger.error(
                "Address not found in keystore",
                error=str(e),
                address=self.config.sui_address,
                hint="The address in your config doesn't exist in the Sui keystore"
            )
            return ""
        except Exception as e:
            logger.error(
                "Failed to sign message",
                error=str(e),
                error_type=type(e).__name__
            )
            return ""
    
    def shutdown(self):
        """Gracefully shutdown miner node."""
        logger.info("Shutting down miner node")
        self.running = False
        
        # Set shutdown event
        if hasattr(self, '_shutdown_event'):
            try:
                self._shutdown_event.set()
            except:
                pass
        
        # Save all indices
        try:
            self.engine.save_all()
        except Exception as e:
            logger.warning("Error saving indices", error=str(e))
        
        logger.info("Miner node shut down")
