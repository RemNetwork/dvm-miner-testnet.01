"""Shared protocol components for DVM."""

