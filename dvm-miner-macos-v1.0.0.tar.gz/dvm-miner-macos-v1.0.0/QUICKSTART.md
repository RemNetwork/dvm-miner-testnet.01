# 🚀 DVM Miner - Quick Start Guide

**Version**: Phase 4 (Latest)  
**Date**: 2025-11-30  
**Package**: miner_package_latest

---

## 📋 PREREQUISITES

- **Python 3.11+**
- **4GB+ RAM** (or more for higher tiers)
- **Sui CLI** (for wallet/signature generation)
- **Linux/Windows** server

---

## 🎯 QUICK START (Copy-Paste Ready!)

### Step 1: Install Dependencies

```bash
# Navigate to package
cd miner_package_latest/miner

# Install Python dependencies
pip install -r requirements.txt

# Install miner package
pip install -e .
```

### Step 2: Generate Sui Wallet (If You Don't Have One)

```bash
# Generate new wallet
sui client new-address ed25519

# Export address
sui client active-address

# Get private key (KEEP SECRET!)
# This will be used in config
```

### Step 3: Initialize Miner

```bash
# Create miner directory
dvm-miner init --data-dir ~/.dvm_miner
```

**This creates**: `~/.dvm_miner/config.json`

### Step 4: Configure Miner

Edit the config:

```bash
nano ~/.dvm_miner/config.json
```

**Required Settings**:

```json
{
  "coordinator_url": "ws://YOUR_COORDINATOR_IP:8000/ws/miner",
  "max_ram_gb": 4,
  "miner_secret": "YOUR_MINER_SECRET_HERE",
  "sui_address": "0xYOUR_SUI_ADDRESS_HERE",
  "sui_private_key": "YOUR_PRIVATE_KEY_HERE",
  "embedding_dim": 384,
  "index_version": "hnsw-v1"
}
```

**Configuration Details**:

| Field | Description | Example |
|-------|-------------|---------|
| `coordinator_url` | Your coordinator WebSocket endpoint | `ws://123.45.67.89:8000/ws/miner` |
| `max_ram_gb` | RAM to dedicate (determines tier) | `4`, `8`, `16`, `32`, `64`, `128` |
| `miner_secret` | Shared secret (must match coordinator) | From `.env` file |
| `sui_address` | Your Sui wallet address | `0x123abc...` (66 chars) |
| `sui_private_key` | Sui wallet private key | `suiprivkey...` |
| `embedding_dim` | Must be `384` | `384` |
| `index_version` | Must be `hnsw-v1` | `hnsw-v1` |

### Step 5: Start Miner

```bash
# Start miner
dvm-miner start --data-dir ~/.dvm_miner
```

**Expected Output**:
```
🚀 Starting DVM Miner...
✓ Config loaded from ~/.dvm_miner/config.json
✓ Sui signature generated
✓ Connecting to coordinator...
✓ Registered with coordinator
✓ Miner online - Tier: T1 (Bronze)
```

---

## 🎛️ TIER SYSTEM

Your tier determines your rewards multiplier:

| Tier | Name | RAM | Multiplier | Rewards |
|------|------|-----|------------|---------|
| T0 | Dreamer | 2GB | 0.5× | Low |
| T1 | Bronze | 4-7GB | 0.8× | Moderate |
| T2 | Silver | 8-15GB | 1.0× | Standard |
| T3 | Gold | 16-31GB | 1.3× | Good |
| T4 | Diamond | 32-63GB | 1.6× | High |
| T5 | Titan | 64-128GB | 2.0× | Maximum |

**Recommendation**: Start with **T2 (8GB)** for good rewards/cost ratio.

---

## 🔗 REFERRAL CODE (Optional)

To get a **10% bonus** for your referrer:

1. Get a referral code from an existing miner (their `node_id`)
2. Add to config:
   ```json
   {
     "referral_code": "EXISTING_MINER_NODE_ID_HERE"
   }
   ```
3. Restart miner

**Note**: Referral can only be set during FIRST registration!

---

## 🐛 TROUBLESHOOTING

### Issue: "Connection refused"
**Fix**: Check coordinator URL and port
```bash
# Test coordinator is running
curl http://YOUR_COORDINATOR_IP:8000/health
```

### Issue: "Invalid miner secret"
**Fix**: Verify `miner_secret` matches coordinator's `.env` file

### Issue: "Invalid Sui address format"
**Fix**: Ensure address starts with `0x` and is exactly 66 characters

### Issue: "Signature verification failed"
**Fix**: 
1. Check `sui_private_key` is correct
2. Make sure it matches the `sui_address`
3. Try regenerating signature

### Issue: Low tier assigned
**Fix**: Increase `max_ram_gb` in config

### Issue: Miner keeps disconnecting
**Fix**: 
1. Check network stability
2. Ensure server has enough RAM
3. Check coordinator logs for errors

---

## 📊 MONITORING

### Check Miner Status

```bash
# View miner logs
dvm-miner logs --data-dir ~/.dvm_miner

# Check if running
ps aux | grep dvm-miner
```

### Check on Coordinator

```bash
# From coordinator server
curl http://localhost:8000/api/metrics
```

Look for your `node_id` in online miners.

### Check Reputation

Your miner's reputation is calculated as:

```
Score = Challenge(40%) + Uptime(30%) + Tier(20%) + Queries(10%)
```

**Target**: 70+ score (Reliable tier)

---

## 🔄 MAINTENANCE

### Update Miner

```bash
# Stop current miner
pkill -f dvm-miner

# Pull new package from coordinator
# (Copy new miner_package_latest from coordinator)

# Reinstall
cd miner_package_latest/miner
pip install -e . --force-reinstall

# Restart
dvm-miner start --data-dir ~/.dvm_miner
```

### View Logs

```bash
# Real-time logs
tail -f ~/.dvm_miner/miner.log

# Last 100 lines
tail -n 100 ~/.dvm_miner/miner.log
```

### Graceful Shutdown

```bash
# Send SIGTERM (graceful exit, no penalty)
pkill -TERM -f dvm-miner

# Or use Ctrl+C if running in foreground
```

**IMPORTANT**: Always use graceful shutdown! Abandoning (hard kill) results in 50% reward penalty.

---

## 🚀 RUNNING AS SERVICE (Linux)

Create systemd service file:

```bash
sudo nano /etc/systemd/system/dvm-miner.service
```

Content:

```ini
[Unit]
Description=DVM Miner Service
After=network.target

[Service]
Type=simple
User=YOUR_USERNAME
WorkingDirectory=/home/YOUR_USERNAME
ExecStart=/usr/bin/python3 -m dvm_miner.main start --data-dir /home/YOUR_USERNAME/.dvm_miner
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable and start:

```bash
sudo systemctl daemon-reload
sudo systemctl enable dvm-miner
sudo systemctl start dvm-miner

# Check status
sudo systemctl status dvm-miner

# View logs
sudo journalctl -u dvm-miner -f
```

---

## 💰 REWARDS

### How Rewards Work

```
Total Reward = Mining Reward + Referral Bonus

Mining Reward = Base × Tier_Mult × Uptime² × Exit_Mult

Base = (Capacity×50%) + (Challenges×40%) + (Queries×10%)
```

### Maximize Rewards

1. **Stay Online**: 100% uptime = full rewards, 50% uptime = 25% rewards (quadratic!)
2. **Pass Challenges**: Run real RAM, don't fake it (40% of rewards)
3. **Higher Tier**: More RAM = higher multiplier
4. **Refer Others**: 10% bonus per referral
5. **Serve Queries**: Be fast and available

---

## 🔒 SECURITY

### Private Key Safety

- **NEVER** share your `sui_private_key`
- Keep `config.json` permissions restricted:
  ```bash
  chmod 600 ~/.dvm_miner/config.json
  ```
- Use a dedicated Sui wallet for mining

### Best Practices

1. Run miner on dedicated server (not personal computer)
2. Use firewall to restrict access
3. Keep miner package updated
4. Monitor logs for suspicious activity
5. Backup your Sui private key securely

---

## 📞 SUPPORT

### If You Need Help

1. Check coordinator logs: `tail -f coordinator/logs/coordinator.log`
2. Check miner logs: `tail -f ~/.dvm_miner/miner.log`
3. Test connection: `curl http://COORDINATOR:8000/health`
4. Contact network admin

### Useful Commands

```bash
# Test Sui CLI
sui client active-address

# Check Python version
python3 --version

# Check installed packages
pip list | grep dvm

# Network test
ping COORDINATOR_IP

# Port test
telnet COORDINATOR_IP 8000
```

---

## ✅ CHECKLIST

Before starting your miner:

- [ ] Python 3.11+ installed
- [ ] Sui CLI installed and wallet created
- [ ] Coordinator URL and port accessible
- [ ] Miner secret obtained from coordinator admin
- [ ] Config file created and filled
- [ ] Sui address and private key added
- [ ] RAM allocated (4GB minimum)
- [ ] Dependencies installed
- [ ] Miner package installed

Ready to start!

```bash
dvm-miner start --data-dir ~/.dvm_miner
```

---

**Package Version**: Phase 4 (2025-11-30)  
**Support**: Contact your coordinator administrator  
**Documentation**: See coordinator README.md for more details
