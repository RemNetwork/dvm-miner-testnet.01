"""
Sui keystore handling for signature generation.
This module reads the Sui CLI keystore file and generates signatures.
"""

import base64
import hashlib
import json
from pathlib import Path
from typing import Optional, Tuple

import structlog

logger = structlog.get_logger(__name__)


def find_sui_keystore() -> Optional[Path]:
    """
    Find the Sui keystore file.
    
    Returns:
        Path to keystore file, or None if not found
    """
    # Try default Sui config location
    home = Path.home()
    keystore_path = home / ".sui" / "sui_config" / "sui.keystore"
    
    if keystore_path.exists():
        return keystore_path
    
    # Try alternative locations
    alt_paths = [
        home / ".sui" / "keystore" / "sui.keystore",
        Path("/etc/sui/sui.keystore"),
    ]
    
    for path in alt_paths:
        if path.exists():
            return path
    
    return None


def load_keystore(keystore_path: Optional[Path] = None) -> dict:
    """
    Load the Sui keystore file.
    
    Args:
        keystore_path: Path to keystore file, or None to auto-detect
        
    Returns:
        Dictionary mapping addresses to private keys
    """
    if keystore_path is None:
        keystore_path = find_sui_keystore()
    
    if keystore_path is None or not keystore_path.exists():
        raise FileNotFoundError(f"Sui keystore not found")
    
    with open(keystore_path, 'r') as f:
        keystore_data = json.load(f)
    
    # Keystore format: list of base64-encoded keys with scheme prefix
    # Example: ["AQEhqE7..."] where first byte is scheme (0=Ed25519, 1=Secp256k1)
    keys = {}
    
    for key_entry in keystore_data:
        try:
            # Decode the key
            key_bytes = base64.b64decode(key_entry)
            
            # First byte is the scheme
            scheme = key_bytes[0]
            private_key = key_bytes[1:33]  # 32 bytes for Ed25519/Secp256k1
            
            # Derive the address from the public key
            if scheme == 0:  # Ed25519
                address = derive_ed25519_address(private_key)
            elif scheme == 1:  # Secp256k1
                address = derive_secp256k1_address(private_key)
            else:
                logger.warning(f"Unknown key scheme: {scheme}")
                continue
            
            keys[address] = {
                'scheme': scheme,
                'private_key': private_key,
                'raw': key_entry
            }
        except Exception as e:
            logger.warning(f"Failed to parse key entry: {e}")
            continue
    
    return keys


def derive_ed25519_address(private_key: bytes) -> str:
    """
    Derive Sui address from Ed25519 private key.
    
    Args:
        private_key: 32-byte Ed25519 private key
        
    Returns:
        Sui address (0x...)
    """
    try:
        from nacl.signing import SigningKey
        from nacl.encoding import RawEncoder
        
        # Create signing key
        signing_key = SigningKey(private_key)
        public_key = signing_key.verify_key.encode(encoder=RawEncoder)
        
        # Sui address = Blake2b-256(0x00 || public_key)[0:32]
        # 0x00 is the Ed25519 flag
        data = b'\x00' + public_key
        hash_result = hashlib.blake2b(data, digest_size=32).digest()
        
        return '0x' + hash_result.hex()
    except Exception as e:
        logger.error(f"Failed to derive Ed25519 address: {e}")
        raise


def derive_secp256k1_address(private_key: bytes) -> str:
    """
    Derive Sui address from Secp256k1 private key.
    
    Args:
        private_key: 32-byte Secp256k1 private key
        
    Returns:
        Sui address (0x...)
    """
    try:
        from coincurve import PrivateKey
        
        # Create private key object
        privkey = PrivateKey(private_key)
        public_key = privkey.public_key.format(compressed=True)  # 33 bytes compressed
        
        # Sui address = Blake2b-256(0x01 || public_key)[0:32]
        # 0x01 is the Secp256k1 flag
        data = b'\x01' + public_key
        hash_result = hashlib.blake2b(data, digest_size=32).digest()
        
        return '0x' + hash_result.hex()
    except Exception as e:
        logger.error(f"Failed to derive Secp256k1 address: {e}")
        raise


def sign_message_ed25519(message: bytes, private_key: bytes) -> bytes:
    """
    Sign a message with Ed25519.
    
    Args:
        message: Message to sign (already hashed if needed)
        private_key: 32-byte Ed25519 private key
        
    Returns:
        64-byte signature
    """
    from nacl.signing import SigningKey
    from nacl.encoding import RawEncoder
    
    signing_key = SigningKey(private_key)
    signature = signing_key.sign(message, encoder=RawEncoder).signature
    return signature


def sign_message_secp256k1(message: bytes, private_key: bytes) -> bytes:
    """
    Sign a message with Secp256k1.
    
    Args:
        message: Message to sign (already hashed if needed)
        private_key: 32-byte Secp256k1 private key
        
    Returns:
        64-byte signature (r || s)
    """
    from coincurve import PrivateKey
    
    privkey = PrivateKey(private_key)
    # Sign the message hash
    signature = privkey.sign(message, hasher=None)  # Already hashed
    # Return raw signature (64 bytes: r || s)
    return signature[:64]


def sign_message(message: str, sui_address: str, keystore_path: Optional[Path] = None) -> str:
    """
    Sign a message with the Sui keypair for the given address.
    
    Args:
        message: Message to sign
        sui_address: Sui address to sign with
        keystore_path: Path to keystore file, or None to auto-detect
        
    Returns:
        Hex-encoded signature with scheme prefix
        Format: scheme_byte || signature_bytes
    """
    # Load keystore
    keystore = load_keystore(keystore_path)
    
    # Normalize address
    address = sui_address.lower().strip()
    
    # Find the key for this address
    if address not in keystore:
        raise ValueError(f"Address {sui_address} not found in keystore")
    
    key_info = keystore[address]
    scheme = key_info['scheme']
    private_key = key_info['private_key']
    
    # Hash the message
    message_bytes = message.encode('utf-8')
    message_hash = hashlib.sha256(message_bytes).digest()
    
    # Sign based on scheme
    if scheme == 0:  # Ed25519
        signature = sign_message_ed25519(message_hash, private_key)
        # Sui signature format: scheme || signature || public_key
        from nacl.signing import SigningKey
        from nacl.encoding import RawEncoder
        signing_key = SigningKey(private_key)
        public_key = signing_key.verify_key.encode(encoder=RawEncoder)
        
        # Format: 0x00 || 64-byte-signature || 32-byte-pubkey
        full_signature = bytes([0]) + signature + public_key
    elif scheme == 1:  # Secp256k1
        signature = sign_message_secp256k1(message_hash, private_key)
        # Sui signature format: scheme || signature || public_key
        from coincurve import PrivateKey
        privkey = PrivateKey(private_key)
        public_key = privkey.public_key.format(compressed=True)
        
        # Format: 0x01 || 64-byte-signature || 33-byte-compressed-pubkey
        full_signature = bytes([1]) + signature + public_key
    else:
        raise ValueError(f"Unsupported key scheme: {scheme}")
    
    # Return as hex
    return full_signature.hex()


def get_active_address(keystore_path: Optional[Path] = None) -> Optional[str]:
    """
    Get the active address from Sui CLI configuration.
    
    Args:
        keystore_path: Path to keystore file, or None to auto-detect
        
    Returns:
        Sui address, or None if no active address found
    """
    try:
        # First, try to read the active address from Sui CLI config
        home = Path.home()
        client_config_path = home / ".sui" / "sui_config" / "client.yaml"
        
        if client_config_path.exists():
            import yaml
            with open(client_config_path, 'r') as f:
                config = yaml.safe_load(f)
                active_address = config.get('active_address')
                if active_address:
                    logger.debug(f"Found active address in client.yaml: {active_address}")
                    return active_address.lower()
        
        # Fallback: get first address from keystore
        keystore = load_keystore(keystore_path)
        if keystore:
            first_addr = next(iter(keystore.keys()))
            logger.warning(f"No active address in config, using first keystore entry: {first_addr}")
            return first_addr
        return None
    except Exception as e:
        logger.error(f"Failed to get active address: {e}")
        return None


