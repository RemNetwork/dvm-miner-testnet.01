"""Miner package setup."""

from setuptools import find_packages, setup

setup(
    name="dvm-miner",
    version="1.0.0",
    description="DVM Miner Node",
    author="DVM Team",
    packages=find_packages(),
    install_requires=[
        "hnswlib>=0.7.0",
        "numpy>=1.24.0",
        "websockets>=12.0",
        "structlog>=23.0.0",
        "click>=8.1.0",
        "zstandard>=0.21.0",
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "dvm-miner=dvm_miner.cli:cli",
        ],
    },
)

