#!/bin/bash
# Quick Setup Script for DVM Miner (Linux/Mac)

set -e

echo "=================================="
echo "DVM Miner - Quick Setup"
echo "=================================="
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 1. Check Python version
echo "Checking Python version..."
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "  Found: Python $python_version"

# 2. Install dependencies
echo ""
echo "${YELLOW}Installing dependencies...${NC}"
cd miner
pip install -r requirements.txt
pip install -e .
cd ..

echo ""
echo "${GREEN}✓ Dependencies installed${NC}"

# 3. Initialize miner
echo ""
echo "${YELLOW}Initializing miner...${NC}"
DATA_DIR="${HOME}/.dvm_miner"

if [ ! -d "$DATA_DIR" ]; then
    dvm-miner init --data-dir "$DATA_DIR"
    echo "${GREEN}✓ Miner initialized at $DATA_DIR${NC}"
else
    echo "  Miner already initialized at $DATA_DIR"
fi

# 4. Prompt for configuration
echo ""
echo "=================================="
echo "CONFIGURATION REQUIRED"
echo "=================================="
echo ""
echo "You need to edit the config file with your details:"
echo "  File: $DATA_DIR/config.json"
echo ""
echo "Required fields:"
echo "  1. coordinator_url - Your coordinator WebSocket URL"
echo "  2. miner_secret - Secret from coordinator admin"
echo "  3. sui_address - Your Sui wallet address"
echo "  4. sui_private_key - Your Sui private key"
echo "  5. max_ram_gb - RAM to allocate (4, 8, 16, 32, 64, 128)"
echo ""
echo "${YELLOW}Opening config file...${NC}"

# Try to open with available editor
if command -v nano &> /dev/null; then
    nano "$DATA_DIR/config.json"
elif command -v vi &> /dev/null; then
    vi "$DATA_DIR/config.json"
else
    echo "Please edit manually: $DATA_DIR/config.json"
    echo "Press Enter when done..."
    read
fi

# 5. Ready to start
echo ""
echo "=================================="
echo "${GREEN}SETUP COMPLETE!${NC}"
echo "=================================="
echo ""
echo "To start your miner:"
echo "  ${GREEN}dvm-miner start --data-dir $DATA_DIR${NC}"
echo ""
echo "Or use the startup script:"
echo "  ${GREEN}./start_miner.sh${NC}"
echo ""
echo "To run as background service:"
echo "  See QUICKSTART.md for systemd setup"
echo ""
