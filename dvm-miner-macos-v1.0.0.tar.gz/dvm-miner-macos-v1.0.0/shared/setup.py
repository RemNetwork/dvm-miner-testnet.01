"""Shared protocol package setup."""

from setuptools import find_packages, setup

setup(
    name="dvm-shared",
    version="1.0.0",
    description="DVM Shared Protocol",
    author="DVM Team",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.24.0",
        "zstandard>=0.21.0",
        "pydantic>=2.0.0",
    ],
    python_requires=">=3.11",
)

