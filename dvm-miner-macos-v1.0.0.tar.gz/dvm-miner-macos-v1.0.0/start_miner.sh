#!/bin/bash
# Start DVM Miner

DATA_DIR="${HOME}/.dvm_miner"

echo "🚀 Starting DVM Miner..."
echo "   Data directory: $DATA_DIR"
echo ""

# Check if config exists
if [ ! -f "$DATA_DIR/config.json" ]; then
    echo "❌ Miner not configured yet!"
    echo ""
    echo "Please run the interactive setup first:"
    echo "   ./interactive_setup.sh"
    echo ""
    echo "Or run manually: dvm-miner init --sui-address YOUR_ADDRESS"
    exit 1
fi

# Start miner
dvm-miner start --data-dir "$DATA_DIR"
