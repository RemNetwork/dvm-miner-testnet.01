# 🎯 START HERE - DVM Miner Setup

## In 3 Simple Steps:

### Step 1: Get Python 3.11+
Download from: https://www.python.org/downloads/

### Step 2: Run Setup Script

**Windows:**
```powershell
.\interactive_setup.ps1
```

**Linux/macOS:**
```bash
chmod +x interactive_setup.sh
./interactive_setup.sh
```

### Step 3: That's It!
The script will guide you through:
- ✅ Sui wallet creation (or use existing)
- ✅ RAM commitment selection
- ✅ Referral code setup
- ✅ Automatic miner configuration

---

## What Happens During Setup?

1. **Python Check**: Verifies Python 3.11+ is installed
2. **Sui Wallet**: Creates or detects your Sui wallet
3. **RAM Selection**: You choose how much RAM to commit (4-128GB)
4. **Referral**: Optional referral code (default provided)
5. **Configuration**: Everything is configured automatically
6. **Ready to Mine!**: Just run `dvm-miner start`

---

## After Setup

### Start Mining:
```bash
dvm-miner start
```

### Your Referral ID:
Check: `~/.dvm_miner/referral_info.txt` (or `%USERPROFILE%\.dvm_miner\referral_info.txt` on Windows)

Share it with friends to earn 10% of their mining rewards!

---

## Need More Info?

- **Full Guide**: See `README.md`
- **Detailed Docs**: See `QUICKSTART.md`
- **Troubleshooting**: Check logs at `~/.dvm_miner/miner.log`

---

**Questions?** Everything is pre-configured. Just run the setup script and follow the prompts! 🚀
