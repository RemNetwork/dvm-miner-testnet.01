# Interactive Setup Script for DVM Miner (Windows PowerShell)
# This script guides users through the complete miner setup with minimum friction

$ErrorActionPreference = "Stop"

# ASCII Art Banner
Write-Host ""
Write-Host "╔════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║                                                    ║" -ForegroundColor Cyan
Write-Host "║          DVM MINER INTERACTIVE SETUP               ║" -ForegroundColor Cyan
Write-Host "║                                                    ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""
Write-Host "Welcome to the DVM Network Mining Setup!" -ForegroundColor Yellow
Write-Host "This wizard will guide you through the setup process step by step."
Write-Host ""

# Step 1: Check Python
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue
Write-Host "Step 1/5: Checking Python Installation" -ForegroundColor Blue
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue

try {
    $pythonVersion = python --version 2>&1
    Write-Host "✓ $pythonVersion found" -ForegroundColor Green
}
catch {
    Write-Host "✗ Python is not installed!" -ForegroundColor Red
    Write-Host "Please install Python 3.11 or higher from https://python.org"
    exit 1
}
Write-Host ""

# Step 2: Check/Install Sui CLI
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue
Write-Host "Step 2/5: Sui CLI Setup" -ForegroundColor Blue
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue

$SUI_ADDRESS = ""

if (Get-Command sui -ErrorAction SilentlyContinue) {
    Write-Host "✓ Sui CLI is already installed" -ForegroundColor Green
    
    # Check if wallet exists
    try {
        $detectedAddress = sui client active-address 2>$null
        if ($detectedAddress) {
            Write-Host "✓ Found existing Sui wallet" -ForegroundColor Green
            Write-Host "  Address: $detectedAddress" -ForegroundColor Cyan
            Write-Host ""
            $useExisting = Read-Host "Do you want to use this wallet for mining? (y/n)"
            
            if ($useExisting -match "^[Yy]$") {
                $SUI_ADDRESS = $detectedAddress
                Write-Host "✓ Using existing wallet" -ForegroundColor Green
            }
        }
    }
    catch {
        # No wallet found
    }
}
else {
    Write-Host "⚠ Sui CLI is not installed" -ForegroundColor Yellow
    Write-Host "Installing Sui CLI automatically..." -ForegroundColor Yellow
    Write-Host ""
    
    # Download and install Sui CLI for Windows
    $suiInstallDir = "$env:USERPROFILE\.sui\bin"
    New-Item -ItemType Directory -Force -Path $suiInstallDir | Out-Null
    
    Write-Host "Downloading Sui CLI binary..." -ForegroundColor Yellow
    
    # Download the Windows binary from official releases
    $suiUrl = "https://github.com/MystenLabs/sui/releases/download/mainnet-v1.14.2/sui-mainnet-v1.14.2-windows-x86_64.zip"
    $downloadPath = "$env:TEMP\sui-windows.zip"
    
    try {
        Invoke-WebRequest -Uri $suiUrl -OutFile $downloadPath -UseBasicParsing
        
        # Extract the zip
        Expand-Archive -Path $downloadPath -DestinationPath $env:TEMP\sui-extract -Force
        
        # Move the executable
        Copy-Item "$env:TEMP\sui-extract\sui.exe" -Destination "$suiInstallDir\sui.exe" -Force
        
        # Clean up
        Remove-Item $downloadPath -Force
        Remove-Item "$env:TEMP\sui-extract" -Recurse -Force
        
        # Add to PATH for current session
        $env:Path = "$suiInstallDir;$env:Path"
        
        # Add to user PATH permanently
        $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
        if ($userPath -notlike "*$suiInstallDir*") {
            [Environment]::SetEnvironmentVariable("Path", "$suiInstallDir;$userPath", "User")
        }
        
        Write-Host ""
        Write-Host "✓ Sui CLI installed successfully" -ForegroundColor Green
    }
    catch {
        Write-Host "✗ Failed to install Sui CLI automatically" -ForegroundColor Red
        Write-Host "Error: $_" -ForegroundColor Red
        Write-Host ""
        Write-Host "Please install manually using one of these methods:" -ForegroundColor Yellow
        Write-Host "  1. Chocolatey: choco install sui"
        Write-Host "  2. Download from: https://docs.sui.io/guides/developer/getting-started/sui-install"
        Write-Host ""
        $continueWithoutSui = Read-Host "Do you want to continue without Sui CLI? (You'll need to provide your address manually) (y/n)"
        
        if ($continueWithoutSui -notmatch "^[Yy]$") {
            Write-Host "Setup cancelled."
            exit 0
        }
    }
}

# Create new wallet if needed
if ([string]::IsNullOrEmpty($SUI_ADDRESS) -and (Get-Command sui -ErrorAction SilentlyContinue)) {
    Write-Host ""
    $createWallet = Read-Host "Do you want to create a new Sui wallet now? (y/n)"
    
    if ($createWallet -match "^[Yy]$") {
        Write-Host ""
        Write-Host "Creating new Sui wallet..." -ForegroundColor Yellow
        Write-Host ""
        
        # Create new wallet
        sui client new-address ed25519
        
        # Get the address
        $SUI_ADDRESS = sui client active-address 2>$null
        
        Write-Host ""
        Write-Host "✓ Wallet created successfully!" -ForegroundColor Green
        Write-Host "  Address: $SUI_ADDRESS" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "╔════════════════════════════════════════════════════╗" -ForegroundColor Red
        Write-Host "║           IMPORTANT: BACKUP YOUR WALLET!          ║" -ForegroundColor Red
        Write-Host "╚════════════════════════════════════════════════════╝" -ForegroundColor Red
        Write-Host ""
        Write-Host "Your wallet recovery phrase was shown above."
        Write-Host "Write it down and store it in a safe place!" -ForegroundColor Yellow
        Write-Host "You will need it to recover your wallet if you lose access."
        Write-Host ""
        Read-Host "Press Enter after you have safely stored your recovery phrase"
    }
}

# Manual address input if still not set
if ([string]::IsNullOrEmpty($SUI_ADDRESS)) {
    Write-Host ""
    while ($true) {
        $manualAddress = Read-Host "Enter your Sui wallet address (0x...)"
        
        # Validate format
        if ($manualAddress -match "^0x[a-fA-F0-9]{64}$") {
            $SUI_ADDRESS = $manualAddress
            Write-Host "✓ Valid address format" -ForegroundColor Green
            break
        }
        else {
            Write-Host "✗ Invalid address format. Must be 0x followed by 64 hex characters" -ForegroundColor Red
        }
    }
}

Write-Host ""

# Step 3: Install Dependencies
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue
Write-Host "Step 3/5: Installing Miner Dependencies" -ForegroundColor Blue
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue

Set-Location miner
Write-Host "Installing Python packages..." -ForegroundColor Yellow
pip install -q -r requirements.txt
pip install -q -e .
Set-Location ..

Write-Host "✓ Dependencies installed" -ForegroundColor Green
Write-Host ""

# Step 4: Configure RAM
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue
Write-Host "Step 4/5: RAM Configuration" -ForegroundColor Blue
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue

Write-Host ""
Write-Host "Choose how much RAM you want to commit to the network:"
Write-Host ""
Write-Host "  Tier    RAM        Multiplier  Monthly Potential*"
Write-Host "  ────────────────────────────────────────────────"
Write-Host "  T1      4GB        0.8×        ~40 REM"
Write-Host "  T2      8GB        1.0×        ~100 REM"
Write-Host "  T3      16GB       1.3×        ~260 REM"
Write-Host "  T4      32GB       1.6×        ~640 REM"
Write-Host "  T5      64GB       2.0×        ~1,600 REM"
Write-Host "  T6      128GB      2.5×        ~4,000 REM"
Write-Host ""
Write-Host "  * Estimated based on 100% uptime and good performance"
Write-Host ""

while ($true) {
    $ramGb = Read-Host "Enter RAM commitment in GB (4, 8, 16, 32, 64, or 128)"
    
    if ($ramGb -match "^(4|8|16|32|64|128)$") {
        Write-Host "✓ RAM commitment set to ${ramGb}GB" -ForegroundColor Green
        break
    }
    else {
        Write-Host "✗ Please choose: 4, 8, 16, 32, 64, or 128" -ForegroundColor Red
    }
}

Write-Host ""

# Step 5: Referral Code
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue
Write-Host "Step 5/5: Referral Code (Optional)" -ForegroundColor Blue
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue

Write-Host ""
Write-Host "If someone referred you to DVM Network, enter their referral code."
Write-Host "They will earn 10% bonus from your mining rewards (doesn't affect your rewards)."
Write-Host ""
$DEFAULT_REFERRAL = "f5e3a292-b3fc-480e-93c6-b475cffd6c18"
$referralCode = Read-Host "Enter referral code (press Enter to use default)"

if ([string]::IsNullOrEmpty($referralCode)) {
    $referralCode = $DEFAULT_REFERRAL
    Write-Host "Using default referral code" -ForegroundColor Yellow
}

Write-Host ""

# Initialize Miner
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue
Write-Host "Initializing Miner..." -ForegroundColor Blue
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue

$DATA_DIR = "$env:USERPROFILE\.dvm_miner"
New-Item -ItemType Directory -Force -Path $DATA_DIR | Out-Null

# Create config
$config = @{
    coordinator_url  = "wss://api.getrem.online/miners_ws"
    data_dir         = $DATA_DIR
    node_id          = ""
    max_ram_gb       = [int]$ramGb
    embedding_dim    = 384
    index_version    = 1
    miner_secret     = "xuLHbzL7awVGHe-PQpAmwRuVJodUtwFRKGhSnAKS8pQ"
    sui_address      = $SUI_ADDRESS
    referral_address = $referralCode
}

$config | ConvertTo-Json | Set-Content "$DATA_DIR\config.json"

Write-Host "✓ Configuration saved to $DATA_DIR\config.json" -ForegroundColor Green
Write-Host ""

# Success!
Write-Host ""
Write-Host "╔════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║              SETUP COMPLETED! 🎉                   ║" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Write-Host "Configuration Summary:" -ForegroundColor Cyan
Write-Host "  Sui Address:     $SUI_ADDRESS" -ForegroundColor Yellow
Write-Host "  RAM Commitment:  ${ramGb}GB" -ForegroundColor Yellow
Write-Host "  Referral Code:   $referralCode" -ForegroundColor Yellow
Write-Host "  Data Directory:  $DATA_DIR" -ForegroundColor Yellow
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host ""
Write-Host "  1. Start your miner:"
Write-Host "     dvm-miner start" -ForegroundColor Green
Write-Host ""
Write-Host "  2. Or use the startup script:"
Write-Host "     .\start_miner.ps1" -ForegroundColor Green
Write-Host ""
Write-Host "  3. Run as background service (recommended):"
Write-Host "     See QUICKSTART.md for Windows Service setup"
Write-Host ""
Write-Host "Your Referral Link:" -ForegroundColor Cyan
Write-Host "  Once your miner is registered, you'll receive your unique Node ID."
Write-Host "  Share it with others to earn 10% of their mining rewards!"
Write-Host "  Your referral info will be saved to: $DATA_DIR\referral_info.txt"
Write-Host ""
Write-Host "Important:" -ForegroundColor Yellow
Write-Host "  • Keep your Sui wallet recovery phrase safe"
Write-Host "  • The miner needs to run 24/7 for best rewards"
Write-Host "  • Monitor your miner regularly"
Write-Host ""
