"""DVM Miner node."""

