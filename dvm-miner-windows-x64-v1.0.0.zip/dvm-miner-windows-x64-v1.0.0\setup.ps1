# Quick Setup Script for DVM Miner (Windows PowerShell)

Write-Host "==================================" -ForegroundColor Cyan
Write-Host "DVM Miner - Quick Setup" -ForegroundColor Cyan
Write-Host "==================================" -ForegroundColor Cyan
Write-Host ""

# 1. Check Python version
Write-Host "Checking Python version..." -ForegroundColor Yellow
$pythonVersion = python --version 2>&1
Write-Host "  Found: $pythonVersion"

# 2. Install dependencies
Write-Host ""
Write-Host "Installing dependencies..." -ForegroundColor Yellow
Set-Location miner
pip install -r requirements.txt
pip install -e .
Set-Location ..

Write-Host ""
Write-Host "Dependencies installed" -ForegroundColor Green

# 3. Initialize miner
Write-Host ""
Write-Host "Initializing miner..." -ForegroundColor Yellow
$dataDir = "$env:USERPROFILE\.dvm_miner"

if (-Not (Test-Path $dataDir)) {
    dvm-miner init --data-dir $dataDir
    Write-Host "Miner initialized at $dataDir" -ForegroundColor Green
} else {
    Write-Host "  Miner already initialized at $dataDir"
}

# 4. Configuration prompt
Write-Host ""
Write-Host "==================================" -ForegroundColor Cyan
Write-Host "CONFIGURATION REQUIRED" -ForegroundColor Cyan
Write-Host "==================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "You need to edit the config file with your details:"
Write-Host "  File: $dataDir\config.json"
Write-Host ""
Write-Host "Required fields:"
Write-Host "  1. coordinator_url - Your coordinator WebSocket URL"
Write-Host "  2. miner_secret - Secret from coordinator admin"
Write-Host "  3. sui_address - Your Sui wallet address"
Write-Host "  4. sui_private_key - Your Sui private key"
Write-Host "  5. max_ram_gb - RAM to allocate (4, 8, 16, 32, 64, 128)"
Write-Host ""
Write-Host "Opening config file..." -ForegroundColor Yellow

# Open with notepad
notepad "$dataDir\config.json"

Write-Host ""
Write-Host "Waiting for you to save and close the file..."
Write-Host "Press Enter when done..."
$null = Read-Host

# 5. Ready to start
Write-Host ""
Write-Host "==================================" -ForegroundColor Cyan
Write-Host "SETUP COMPLETE!" -ForegroundColor Green
Write-Host "==================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "To start your miner:" -ForegroundColor Yellow
Write-Host "  dvm-miner start --data-dir $dataDir" -ForegroundColor Green
Write-Host ""
Write-Host "Or use the startup script:" -ForegroundColor Yellow
Write-Host "  .\start_miner.ps1" -ForegroundColor Green
Write-Host ""
