"""Protocol serialization tests."""

import numpy as np
import pytest

from shared.protocol.serialization import (
    decode_query_vector,
    decode_vectors,
    encode_query_vector,
    encode_vectors,
)


def test_encode_decode_vectors():
    """Test vector encoding/decoding roundtrip."""
    vectors = np.random.rand(100, 384).astype(np.float32)
    b64, shape = encode_vectors(vectors)
    decoded = decode_vectors(b64, shape)
    
    assert decoded.shape == vectors.shape
    assert decoded.dtype == np.float32
    assert np.allclose(vectors, decoded, rtol=1e-5)


def test_encode_decode_query_vector():
    """Test query vector encoding/decoding roundtrip."""
    query = np.random.rand(384).astype(np.float32)
    b64, shape = encode_query_vector(query)
    decoded = decode_query_vector(b64, shape)
    
    assert decoded.shape == query.shape
    assert decoded.dtype == np.float32
    assert np.allclose(query, decoded, rtol=1e-5)

