# Start DVM Miner (Windows PowerShell)

$dataDir = "$env:USERPROFILE\.dvm_miner"

Write-Host "Starting DVM Miner..." -ForegroundColor Cyan
Write-Host "   Data directory: $dataDir"
Write-Host ""

# Check if config exists
if (-Not (Test-Path "$dataDir\config.json")) {
    Write-Host "Miner not configured yet!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please run the interactive setup first:"
    Write-Host "   .\interactive_setup.ps1" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Or run manually: dvm-miner init --sui-address YOUR_ADDRESS"
    exit 1
}

# Start miner
dvm-miner start --data-dir $dataDir
